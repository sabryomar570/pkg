/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { SolutionsLibrary } from './components/SolutionsLibrary';
import { ToolDetailsPage } from './components/ToolDetailsPage';
import { CopyAdBanner } from './components/CopyAdBanner';
import { DraggableContactWidget } from './components/DraggableContactWidget';
import { PomodoroTimerModal } from './components/PomodoroTimerModal';
import { QuranPlayer } from './components/QuranPlayer';
import { ContactFooter } from './components/ContactFooter';
import { chaptersBac1Js, chaptersBac2Js, chaptersPy, chaptersFin } from './data/chaptersData';
import { AcademicGrade, SectionType } from './types';

export default function App() {
  // Theme state (Persisted, dark class on html)
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('smart_theme') === 'dark';
    }
    return false;
  });

  // Active view: 'library' or dedicated 'toolDetails' page
  const [activeView, setActiveView] = useState<'library' | 'toolDetails'>('library');

  // Academic Grade: 'bac1' (أولى بكالوريا: 42 مستوى جافا) or 'bac2' (تانية بكالوريا: 54 جافا + بايثون + المالية)
  const [academicGrade, setAcademicGrade] = useState<AcademicGrade>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('student_academic_grade') as AcademicGrade;
      return saved === 'bac2' ? 'bac2' : 'bac1';
    }
    return 'bac1';
  });

  // Active section for subject: js, py, fin
  const [activeSection, setActiveSection] = useState<SectionType>('js');

  // Modals state
  const [isTimerModalOpen, setIsTimerModalOpen] = useState(false);
  const [isQuranModalOpen, setIsQuranModalOpen] = useState(false);

  // Non-intrusive ad banner control (shows on 1st, 6th, 16th, 26th copy...)
  const [copyCount, setCopyCount] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('student_copy_count');
      return saved ? parseInt(saved, 10) : 0;
    }
    return 0;
  });
  const [showCopyAd, setShowCopyAd] = useState(false);

  // Student Gamification State
  const [xp, setXp] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('student_xp');
      return saved ? parseInt(saved, 10) : 50;
    }
    return 50;
  });

  const [streak, setStreak] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('student_streak');
      return saved ? parseInt(saved, 10) : 3;
    }
    return 3;
  });

  const [completedQuestions, setCompletedQuestions] = useState<Record<string, boolean>>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('student_completed_qs');
      return saved ? JSON.parse(saved) : {};
    }
    return {};
  });

  // Level calculation: 100 XP per level
  const currentLevel = Math.floor(xp / 100) + 1;

  // Apply theme class to document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('smart_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('smart_theme', 'light');
    }
  }, [isDark]);

  // Handle Academic Grade Change
  const handleSelectGrade = (grade: AcademicGrade) => {
    setAcademicGrade(grade);
    localStorage.setItem('student_academic_grade', grade);
    if (grade === 'bac1') {
      setActiveSection('js');
    }
  };

  // Handle question completion (grant XP and persist)
  const handleCompleteQuestion = (key: string) => {
    if (!completedQuestions[key]) {
      const nextCompleted = { ...completedQuestions, [key]: true };
      setCompletedQuestions(nextCompleted);
      localStorage.setItem('student_completed_qs', JSON.stringify(nextCompleted));

      const nextXp = xp + 25;
      setXp(nextXp);
      localStorage.setItem('student_xp', String(nextXp));
    }
  };

  // Handle copy event to selectively trigger non-intrusive promo banner
  const handleCopyTrigger = () => {
    const nextCount = copyCount + 1;
    setCopyCount(nextCount);
    localStorage.setItem('student_copy_count', String(nextCount));

    // Show banner on 1st copy, 6th copy, 16th copy, 26th copy...
    if (nextCount === 1 || nextCount === 6 || (nextCount > 6 && (nextCount - 6) % 10 === 0)) {
      setShowCopyAd(true);
    }
  };

  const handleToggleTheme = () => {
    setIsDark(!isDark);
  };

  const scrollToLibrary = () => {
    setActiveView('library');
    const el = document.getElementById('solutions-library');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Compute chapters according to user selection
  // أولى بكالوريا: الـ 42 مستوى بتوع جافا في البرمجة
  // تانية بكالوريا: نفس الـ 42 بتوع أولى ولكن مضاف عليهم حتى 54 + بايثون + الثقافة المالية
  const currentChapters =
    academicGrade === 'bac1'
      ? chaptersBac1Js
      : activeSection === 'js'
      ? chaptersBac2Js
      : activeSection === 'py'
      ? chaptersPy
      : chaptersFin;

  return (
    <div className="min-h-screen bg-[#EEF2F7] dark:bg-[#0A0D14] text-slate-800 dark:text-slate-100 font-['iOS15Arabic',_'Cairo',_sans-serif] transition-colors duration-300 flex flex-col relative selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar (Apple Style, No Sound button, with Grade Status) */}
      <Navbar
        isDark={isDark}
        onToggleTheme={handleToggleTheme}
        onOpenTimer={() => setIsTimerModalOpen(true)}
        activeView={activeView}
        onSelectView={(view) => {
          setActiveView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        xp={xp}
        level={currentLevel}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeView === 'toolDetails' ? (
          /* Dedicated Tool Page: Mechanism, Live Video Player, Screenshots Gallery, Authentic Egyptian Persona */
          <ToolDetailsPage onBackToLibrary={() => setActiveView('library')} />
        ) : (
          /* Library View: Hero + Academic Grade Solutions List */
          <>
            <HeroSection
              onScrollToLibrary={scrollToLibrary}
              onOpenToolDetails={() => {
                setActiveView('toolDetails');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            <SolutionsLibrary
              chapters={currentChapters}
              academicGrade={academicGrade}
              onSelectGrade={handleSelectGrade}
              activeSection={activeSection}
              onSelectSection={(sec) => setActiveSection(sec)}
              completedQuestions={completedQuestions}
              onCompleteQuestion={handleCompleteQuestion}
              onCopyTrigger={handleCopyTrigger}
              onOpenToolDetails={() => {
                setActiveView('toolDetails');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </>
        )}
      </main>

      {/* Direct Contact Footer */}
      <ContactFooter
        onOpenTimer={() => setIsTimerModalOpen(true)}
        onOpenQuran={() => setIsQuranModalOpen(true)}
        onOpenDemo={() => {
          setActiveView('toolDetails');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Floating Free-Draggable Contact Widget (WhatsApp & Telegram Anywhere) */}
      <DraggableContactWidget />

      {/* Non-intrusive Ad Banner (Triggered gently on 1st, 6th, 16th copy) */}
      <CopyAdBanner
        isVisible={showCopyAd}
        onClose={() => setShowCopyAd(false)}
        copyCount={copyCount}
      />

      {/* Modals */}
      <PomodoroTimerModal
        isOpen={isTimerModalOpen}
        onClose={() => setIsTimerModalOpen(false)}
        onSessionComplete={() => {
          const nextStreak = streak + 1;
          setStreak(nextStreak);
          localStorage.setItem('student_streak', String(nextStreak));
        }}
      />

      <QuranPlayer
        isOpen={isQuranModalOpen}
        onClose={() => setIsQuranModalOpen(false)}
      />
    </div>
  );
}
