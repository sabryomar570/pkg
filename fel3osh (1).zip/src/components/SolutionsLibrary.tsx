import React, { useState } from 'react';
import { Menu, RefreshCw, Trophy, Zap, BookOpen, Layers, CheckCircle2, Award, Sparkles } from 'lucide-react';
import { WhatsAppIcon } from './SocialIcons';
import { Chapter, AcademicGrade, SectionType } from '../types';
import { QuestionCard } from './QuestionCard';
import { ChapterSidebar } from './ChapterSidebar';
import { studentQuotes } from '../data/chaptersData';

interface SolutionsLibraryProps {
  chapters: Chapter[];
  academicGrade: AcademicGrade;
  onSelectGrade: (grade: AcademicGrade) => void;
  activeSection: SectionType;
  onSelectSection: (sec: SectionType) => void;
  completedQuestions: Record<string, boolean>;
  onCompleteQuestion: (key: string) => void;
  onCopyTrigger?: () => void;
  onOpenToolDetails: () => void;
}

export const SolutionsLibrary: React.FC<SolutionsLibraryProps> = ({
  chapters,
  academicGrade,
  onSelectGrade,
  activeSection,
  onSelectSection,
  completedQuestions,
  onCompleteQuestion,
  onCopyTrigger,
  onOpenToolDetails,
}) => {
  const [currentChapterIdx, setCurrentChapterIdx] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpenMobile, setIsOpenMobile] = useState(false);
  const [quoteIdx, setQuoteIdx] = useState(0);

  const safeIdx = currentChapterIdx >= chapters.length ? 0 : currentChapterIdx;
  const currentChapter = chapters[safeIdx] || chapters[0];

  const totalQs = currentChapter ? currentChapter.qs.length : 0;
  let solvedCount = 0;
  if (currentChapter) {
    for (let q = 0; q < totalQs; q++) {
      if (completedQuestions[`${academicGrade}-${activeSection}-${safeIdx}-${q}`]) solvedCount++;
    }
  }
  const chapterProgress = totalQs > 0 ? Math.round((solvedCount / totalQs) * 100) : 0;

  const handleNextQuote = () => {
    setQuoteIdx((prev) => (prev + 1) % studentQuotes.length);
  };

  // Scroll directly in front of the answers list so the student can immediately see and copy the answers
  const scrollToActiveChapter = () => {
    setTimeout(() => {
      const el = document.getElementById('questions-list-top');
      if (el) {
        const yOffset = -80; // sticky navbar offset
        const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
      }
    }, 40);
  };

  const handleChapterNav = (newIdx: number) => {
    setCurrentChapterIdx(newIdx);
    scrollToActiveChapter();
  };

  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');

  const currentQuote = studentQuotes[quoteIdx];

  const getSectionTitle = () => {
    if (academicGrade === 'bac1') {
      return 'أولى بكالوريا — مستويات البرمجة جافا (1 إلى 42)';
    }
    if (activeSection === 'js') return 'تانية بكالوريا — جافا المتقدمة (المستويات 1 إلى 54)';
    if (activeSection === 'py') return 'تانية بكالوريا — لغة بايثون Python (25 فصلاً)';
    return 'تانية بكالوريا — الثقافة المالية والاقتصاد (8 فصول)';
  };

  return (
    <section id="solutions-library" className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-8">
      {/* 1. Academic Level Header Switcher Banner */}
      <div className="clay-card p-4 sm:p-7 mb-5 sm:mb-6 text-right relative overflow-hidden border border-white/80 dark:border-white/10">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <h2 className="text-lg sm:text-2xl font-black font-ios text-slate-900 dark:text-white">
                  مكتبة الحلول المعتمدة
                </h2>
              </div>

              {/* Tag: إجابات المراجعات واختبارات منتصف الطريق */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl clay-inset text-xs font-bold text-indigo-700 dark:text-sky-300 font-decorative w-fit">
                <Award className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>إجابات المراجعات واختبارات منتصف الطريق المعتمدة 100%</span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-ios font-medium leading-relaxed">
              تصفح جميع المستويات والأسئلة وحلول الأكواد النموذجية الجاهزة للنسخ بنقرة واحدة.
            </p>
          </div>

          {/* Tactile Grade Switcher */}
          <div className="flex items-center gap-2 p-1.5 rounded-2xl clay-inset w-full md:w-auto shrink-0">
            <button
              onClick={() => {
                onSelectGrade('bac1');
                setCurrentChapterIdx(0);
              }}
              className={`flex-1 md:flex-initial px-3 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold font-decorative transition-all flex items-center justify-center gap-1.5 ${
                academicGrade === 'bac1'
                  ? 'clay-apple-blue text-white shadow-md'
                  : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>أولى بكالوريا</span>
              <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-md font-mono">(42 مستوى)</span>
            </button>

            <button
              onClick={() => {
                onSelectGrade('bac2');
                setCurrentChapterIdx(0);
              }}
              className={`flex-1 md:flex-initial px-3 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold font-decorative transition-all flex items-center justify-center gap-1.5 ${
                academicGrade === 'bac2'
                  ? 'clay-apple-blue text-white shadow-md'
                  : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>تانية بكالوريا</span>
              <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-md font-mono">(54+ مواد)</span>
            </button>
          </div>
        </div>

        {/* Bac2 Secondary Subject Switcher */}
        {academicGrade === 'bac2' && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 pt-3 mt-3 sm:pt-4 sm:mt-4 border-t border-slate-200/60 dark:border-slate-800/60">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 font-decorative shrink-0">
              المادة الدراسية:
            </span>

            <div className="grid grid-cols-3 gap-1.5 w-full sm:w-auto flex-1">
              <button
                onClick={() => {
                  onSelectSection('js');
                  setCurrentChapterIdx(0);
                }}
                className={`py-2 px-2 rounded-xl text-xs font-bold transition-all font-ios text-center ${
                  activeSection === 'js'
                    ? 'clay-apple-blue text-white'
                    : 'clay-btn text-slate-700 dark:text-slate-300'
                }`}
              >
                جافا (54 مستوى)
              </button>

              <button
                onClick={() => {
                  onSelectSection('py');
                  setCurrentChapterIdx(0);
                }}
                className={`py-2 px-2 rounded-xl text-xs font-bold transition-all font-ios text-center ${
                  activeSection === 'py'
                    ? 'clay-apple-blue text-white'
                    : 'clay-btn text-slate-700 dark:text-slate-300'
                }`}
              >
                بايثون (25)
              </button>

              <button
                onClick={() => {
                  onSelectSection('fin');
                  setCurrentChapterIdx(0);
                }}
                className={`py-2 px-2 rounded-xl text-xs font-bold transition-all font-ios text-center ${
                  activeSection === 'fin'
                    ? 'clay-apple-blue text-white'
                    : 'clay-btn text-slate-700 dark:text-slate-300'
                }`}
              >
                المالية (8)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 2. Omar Sabry's Egyptian Advice Strip */}
      <div className="clay-card p-3 sm:p-4 mb-5 sm:mb-6 flex items-center justify-between gap-2.5 text-right border border-white/80 dark:border-white/10">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 flex items-center justify-center shrink-0 clay-inset">
            <Trophy className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-100 font-ios truncate sm:whitespace-normal">
            "{currentQuote.quote}" <span className="text-[11px] text-indigo-600 dark:text-sky-400 font-bold font-decorative">— أخوك {currentQuote.author}</span>
          </div>
        </div>

        <button
          onClick={handleNextQuote}
          title="نصيحة ثانية من عمر"
          className="clay-btn p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-white shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3. Main Grid: Sidebar + Questions Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-8 items-start">
        {/* Right Content Area: Active Chapter Questions */}
        <div className="lg:col-span-8 flex flex-col gap-4 sm:gap-5 order-2 lg:order-1">
          {/* Active Chapter Header Card - Scroll Anchor */}
          <div
            id="active-chapter-container"
            className="clay-card p-4 sm:p-6 text-right border border-white/80 dark:border-white/10 scroll-mt-24"
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3 sm:mb-4">
              <div className="flex items-center gap-2.5 sm:gap-3">
                <button
                  onClick={() => setIsOpenMobile(true)}
                  className="lg:hidden p-2 rounded-xl clay-btn text-slate-700 dark:text-slate-200 shrink-0"
                  aria-label="افتح الفهرس"
                >
                  <Menu className="w-4 h-4" />
                </button>
                <div>
                  <h2 className="text-base sm:text-2xl font-black font-ios text-slate-900 dark:text-white">
                    {activeSection === 'js' ? `حلول المستوى ${currentChapter?.num}` : `حلول الفصل ${currentChapter?.num}`}
                  </h2>
                  <span className="text-xs text-indigo-600 dark:text-sky-400 font-bold font-decorative block mt-0.5">
                    {getSectionTitle()}
                  </span>
                </div>
              </div>

              {/* Progress Summary Pill */}
              <div className="flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 rounded-2xl clay-inset text-xs font-bold text-slate-700 dark:text-slate-300 font-ios shrink-0">
                <span>تم إنجاز:</span>
                <span className="text-indigo-600 dark:text-sky-400 font-mono">
                  {solvedCount}/{totalQs}
                </span>
                <span className="text-emerald-500">({chapterProgress}%)</span>
              </div>
            </div>

            {/* Chapter Progress Bar */}
            <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden clay-inset">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 via-sky-400 to-emerald-400 rounded-full transition-all duration-300"
                style={{ width: `${chapterProgress}%` }}
              />
            </div>
          </div>

          {/* Omar Sabry Tool Promo Card */}
          <div className="clay-card p-4 sm:p-5 bg-gradient-to-r from-indigo-50/90 via-sky-50/80 to-purple-50/90 dark:from-indigo-950/40 dark:via-sky-950/30 dark:to-purple-950/30 border border-indigo-200/70 dark:border-indigo-800/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 text-right">
            <div className="flex items-start sm:items-center gap-3">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl clay-apple-blue flex items-center justify-center shrink-0 shadow-md">
                <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 fill-amber-300" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white">
                    عايز تخلص كل الفصول دي في 4 دقايق بمحاكاة بشرية تامة؟
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios mt-0.5 leading-relaxed">
                  أداة عمر صبري بتسجل كأنك أنت بالظبط وتكتب وتجاوب بنعومة تامة بدون كشفك في المنصة.
                </p>
              </div>
            </div>

            <div className="flex flex-row items-center gap-2 shrink-0 w-full sm:w-auto">
              <button
                onClick={onOpenToolDetails}
                className="clay-btn flex-1 sm:flex-initial py-2 px-3 text-xs font-bold text-indigo-600 dark:text-sky-400 font-ios text-center whitespace-nowrap"
              >
                شرح الميكانيزم
              </button>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="clay-whatsapp flex-1 sm:flex-initial px-3.5 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 font-ios whitespace-nowrap"
              >
                <WhatsAppIcon className="w-4 h-4" />
                <span>عاوز اشترك يخويااااا</span>
              </a>
            </div>
          </div>

          {/* Questions List - Answers Visible & Ready to Copy Immediately */}
          <div id="questions-list-top" className="flex flex-col gap-3 sm:gap-3.5">
            {currentChapter?.qs.map((q, qIdx) => (
              <QuestionCard
                key={`${academicGrade}-${activeSection}-${safeIdx}-${qIdx}`}
                question={q}
                index={qIdx}
                chapterIndex={safeIdx}
                section={activeSection}
                isCompleted={!!completedQuestions[`${academicGrade}-${activeSection}-${safeIdx}-${qIdx}`]}
                onComplete={() =>
                  onCompleteQuestion(`${academicGrade}-${activeSection}-${safeIdx}-${qIdx}`)
                }
                onCopyTrigger={onCopyTrigger}
              />
            ))}
          </div>

          {/* Bottom Chapter Navigation Bar - Smooth direct landing in front of answers */}
          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              disabled={safeIdx === 0}
              onClick={() => handleChapterNav(Math.max(0, safeIdx - 1))}
              className="clay-btn px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed font-ios whitespace-nowrap"
            >
              المستوى السابق
            </button>

            <span className="text-[11px] sm:text-xs font-bold font-decorative text-slate-500 dark:text-slate-400 text-center px-1">
              {safeIdx + 1} / {chapters.length}
            </span>

            <button
              disabled={safeIdx === chapters.length - 1}
              onClick={() => handleChapterNav(Math.min(chapters.length - 1, safeIdx + 1))}
              className="clay-btn px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed font-ios whitespace-nowrap"
            >
              المستوى القادم
            </button>
          </div>
        </div>

        {/* Left Column: Chapter Sidebar (Desktop Sticky + Mobile Drawer) */}
        <div className="lg:col-span-4 order-1 lg:order-2">
          <ChapterSidebar
            chapters={chapters}
            currentChapterIdx={safeIdx}
            onSelectChapter={(idx) => handleChapterNav(idx)}
            searchQuery={searchQuery}
            onSearchChange={(q) => setSearchQuery(q)}
            academicGrade={academicGrade}
            onSelectGrade={onSelectGrade}
            activeSection={activeSection}
            onSelectSection={(sec) => {
              onSelectSection(sec);
              setCurrentChapterIdx(0);
            }}
            completedQuestions={completedQuestions}
            isOpenMobile={isOpenMobile}
            onCloseMobile={() => setIsOpenMobile(false)}
          />
        </div>
      </div>
    </section>
  );
};
