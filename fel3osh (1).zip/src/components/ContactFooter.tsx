import React from 'react';
import { BookOpen, Clock, Sparkles } from 'lucide-react';
import { WhatsAppIcon, TelegramIcon } from './SocialIcons';

interface ContactFooterProps {
  onOpenTimer: () => void;
  onOpenQuran: () => void;
  onOpenDemo: () => void;
}

export const ContactFooter: React.FC<ContactFooterProps> = ({
  onOpenTimer,
  onOpenQuran,
  onOpenDemo,
}) => {
  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/OmarSaabry';

  return (
    <footer className="mt-16 border-t border-white/60 dark:border-white/5 bg-[#EEF2F7]/95 dark:bg-[#0A0D14]/95 backdrop-blur-xl py-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 text-right">
        {/* Brand Summary */}
        <div className="flex flex-col items-center md:items-start text-center md:text-right gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl clay-card flex items-center justify-center p-1.5 shadow-sm">
              <img
                src="/icon-192.png"
                alt="Logo"
                className="w-full h-full object-contain rounded-xl"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <span className="text-lg font-bold font-decorative text-slate-900 dark:text-white">
                Fel3osh — مكتبة الحلول
              </span>
              <div className="text-xs font-bold text-indigo-600 dark:text-sky-400 font-decorative mt-0.5">
                𝕯𝖊𝖛 : عُـمـر صَـبـري
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 max-w-sm font-ios leading-relaxed">
            المنصة مصممة خصيصاً عشان تشيل عنك سحل المذاكرة وضغط الامتحانات.. شغّل دماغك وخلّص الليلة كلها في 4 دقايق!
          </p>
        </div>

        {/* Quick Utility Tools */}
        <div className="flex flex-wrap items-center justify-center gap-2.5">
          <button
            onClick={onOpenQuran}
            className="clay-btn px-4 py-2.5 rounded-2xl text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-emerald-500" />
            <span className="font-decorative">القرآن الكريم</span>
          </button>

          <button
            onClick={onOpenTimer}
            className="clay-btn px-4 py-2.5 rounded-2xl text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5"
          >
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            <span className="font-decorative">مؤقت بومودورو للتركيز</span>
          </button>
        </div>

        {/* Contact Channels */}
        <div className="flex items-center gap-3">
          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-telegram px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-1.5 text-white"
          >
            <TelegramIcon className="w-4 h-4" />
            <span>تليجرام @OmarSaabry</span>
          </a>

          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-whatsapp px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-1.5 text-white"
          >
            <WhatsAppIcon className="w-4 h-4" />
            <span>عاوز اشترك يخويااااا</span>
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 font-medium text-center gap-2">
        <span>© {new Date().getFullYear()} جميع الحلول والأكواد جاهزة لدعم وحوش البرمجة</span>
        <div className="flex items-center gap-1 justify-center text-slate-600 dark:text-slate-400">
          <span>صُنع خصيصاً لمساعدة الطلاب على التفوق والراحة</span>
        </div>
      </div>
    </footer>
  );
};
