import React, { useState, useEffect } from 'react';
import { MessageCircle, Send, ArrowUp, Flame } from 'lucide-react';

interface FloatingContactBarProps {
  streak: number;
  xp: number;
}

export const FloatingContactBar: React.FC<FloatingContactBarProps> = ({ streak, xp }) => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/omassaabry';

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-[94vw] w-auto">
      <div className="clay-card p-2 sm:p-2.5 flex items-center gap-2 sm:gap-3 rounded-full border border-white/80 dark:border-white/10 shadow-xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl">
        {/* Streak Indicator */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full clay-inset text-amber-600 dark:text-amber-400 text-xs font-bold select-none font-decorative">
          <Flame className="w-4 h-4 fill-amber-500 text-amber-500 animate-pulse" />
          <span>{streak} أيام استمرار</span>
        </div>

        {/* Telegram Icon Button */}
        <a
          href={TELEGRAM_URL}
          target="_blank"
          rel="noopener noreferrer"
          title="تليجرام @omassaabry"
          className="clay-telegram p-2 rounded-full flex items-center justify-center text-white hover:scale-105 active:scale-95 transition-transform"
        >
          <Send className="w-4 h-4" />
        </a>

        {/* WhatsApp Auto-Message CTA Button */}
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="clay-whatsapp px-4 py-2 rounded-full text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-md hover:scale-105 active:scale-95 transition-all text-white font-decorative"
        >
          <MessageCircle className="w-4 h-4" />
          <span>عاوز اشترك يخويااااا</span>
        </a>

        {/* Scroll To Top Button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            title="الصعود لأعلى الصفحة"
            className="p-2 rounded-full clay-btn text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-sky-400 transition-colors"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
