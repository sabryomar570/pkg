import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Copy, Check, Sparkles } from 'lucide-react';
import { QuestionItem } from '../types';
import confetti from 'canvas-confetti';

interface QuestionCardProps {
  question: QuestionItem;
  index: number;
  chapterIndex: number;
  section: string;
  isCompleted: boolean;
  onComplete: () => void;
  onCopyTrigger?: () => void;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  index,
  isCompleted,
  onComplete,
  onCopyTrigger,
}) => {
  // Answers are shown by default as requested to eliminate any delay in copying
  const [isOpen, setIsOpen] = useState(true);
  const [copied, setCopied] = useState(false);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(question.a);
    setCopied(true);
    onComplete();

    if (onCopyTrigger) {
      onCopyTrigger();
    }

    try {
      confetti({
        particleCount: 18,
        spread: 40,
        origin: { y: 0.8 },
        colors: ['#0071E3', '#6366f1', '#10b981'],
        disableForReducedMotion: true,
      });
    } catch {}

    setTimeout(() => setCopied(false), 2000);
  };

  const isHtml = question.a.includes('<') && question.a.includes('>');
  const isCss = question.a.includes('{') && question.a.includes('color:');
  const langTag = question.code ? (isHtml ? 'HTML' : isCss ? 'CSS' : 'CODE') : 'TEXT';

  return (
    <div
      className={`clay-card p-3.5 sm:p-5 transition-all text-right border ${
        isCompleted ? 'border-emerald-500/35' : 'border-white/80 dark:border-white/10'
      }`}
    >
      {/* Header Bar */}
      <div
        onClick={toggleOpen}
        className="cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 select-none"
      >
        <div className="flex items-start sm:items-center gap-2 sm:gap-3 min-w-0 w-full sm:w-auto">
          <div
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 transition-colors mt-0.5 sm:mt-0 ${
              isCompleted
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'clay-inset text-indigo-600 dark:text-sky-400 font-mono'
            }`}
          >
            {index + 1}
          </div>
          <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-800 dark:text-slate-100 whitespace-normal leading-snug flex-1">
            {question.q}
          </h3>
        </div>

        <div className="flex items-center justify-between sm:justify-end gap-2 w-full sm:w-auto pt-2 sm:pt-0 border-t border-slate-200/50 dark:border-slate-800/50 sm:border-0 shrink-0">
          <div className="flex items-center gap-2">
            {question.code ? (
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg clay-inset text-indigo-600 dark:text-sky-400">
                {langTag}
              </span>
            ) : null}

            <div className="p-1 rounded-lg clay-btn text-slate-400">
              {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </div>
          </div>

          {/* Quick Copy Button in Header for Instant One-Tap Access */}
          <button
            onClick={handleCopy}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm font-ios ${
              copied
                ? 'bg-emerald-500 text-white'
                : 'clay-apple-blue text-white'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>تم النسخ ✅</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ الحل 📋</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Answer Body - Open by default */}
      {isOpen && (
        <div className="mt-3 pt-3 border-t border-slate-200/70 dark:border-slate-800/80 animate-in fade-in duration-150">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold font-decorative text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>الإجابة النموذجية المباشرة:</span>
            </span>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 font-ios">
              (انقر داخل الصندوق لنسخ الحل)
            </span>
          </div>

          {/* Answer Box */}
          <div
            onClick={handleCopy}
            title="انقر لنسخ الإجابة فوراً"
            className="cursor-pointer clay-inset p-3 sm:p-4 group hover:ring-2 hover:ring-indigo-400/40 transition-all rounded-2xl relative overflow-hidden"
          >
            {question.code ? (
              <pre
                className="font-['JetBrains_Mono'] text-xs sm:text-[13px] leading-relaxed text-indigo-700 dark:text-sky-300 whitespace-pre-wrap break-all overflow-x-auto text-left"
                dir="ltr"
              >
                {question.a}
              </pre>
            ) : (
              <p className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 leading-relaxed font-ios">
                {question.a}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
