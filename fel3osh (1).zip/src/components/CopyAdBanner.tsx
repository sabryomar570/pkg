import React from 'react';
import { X, Sparkles, MessageCircle, Send, CheckCircle2, Zap } from 'lucide-react';

interface CopyAdBannerProps {
  isVisible: boolean;
  onClose: () => void;
  copyCount: number;
}

export const CopyAdBanner: React.FC<CopyAdBannerProps> = ({ isVisible, onClose, copyCount }) => {
  if (!isVisible) return null;

  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/omassaabry';

  return (
    <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40 w-full max-w-xl px-4 animate-in slide-in-from-bottom-5 duration-300">
      <div className="clay-card p-4 sm:p-5 bg-white/95 dark:bg-slate-900/95 border border-white/80 dark:border-white/10 shadow-2xl relative text-right backdrop-blur-xl">
        {/* Dismiss Button */}
        <button
          onClick={onClose}
          className="absolute top-3 left-3 p-1.5 rounded-xl clay-btn text-slate-400 hover:text-slate-700 dark:hover:text-white"
        >
          <X className="w-3.5 h-3.5" />
        </button>

        <div className="flex items-start gap-3.5 pl-6">
          <div className="w-10 h-10 rounded-2xl clay-apple-blue flex items-center justify-center shrink-0 shadow-md">
            <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold font-decorative text-slate-900 dark:text-white">
                عاش يا باشا زمانك! نسخت الكود بنجاح 📋
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full clay-inset text-emerald-700 dark:text-emerald-300 font-mono font-bold">
                نسخة #{copyCount}
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-ios mb-3">
              شايل هم الامتحان؟ بدل ما تسحل نفسك ليل نهار نسخ ولصق، الأداة بتخلّص الليلة كلها في 4 دقايق بمحاكاة بشرية تامة والمنصة تحلف إنك أينشتاين!
            </p>

            <div className="flex items-center gap-2">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="clay-whatsapp px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 text-white"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>عاوز اشترك يخويااااا</span>
              </a>

              <a
                href={TELEGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="clay-telegram px-3 py-1.5 rounded-xl text-xs font-bold text-white flex items-center gap-1"
              >
                <Send className="w-3 h-3" />
                <span>@omassaabry</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
