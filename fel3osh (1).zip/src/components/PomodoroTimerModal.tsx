import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Clock, Coffee, Sparkles } from 'lucide-react';
import { sounds } from '../utils/soundEffects';

interface PomodoroTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSessionComplete?: () => void;
}

export const PomodoroTimerModal: React.FC<PomodoroTimerModalProps> = ({
  isOpen,
  onClose,
  onSessionComplete,
}) => {
  const STUDY_TIME = 25 * 60; // 25 minutes
  const BREAK_TIME = 5 * 60; // 5 minutes

  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [timeLeft, setTimeLeft] = useState(STUDY_TIME);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      sounds.playLevelUp();
      if (mode === 'study') {
        setMode('break');
        setTimeLeft(BREAK_TIME);
        if (onSessionComplete) onSessionComplete();
      } else {
        setMode('study');
        setTimeLeft(STUDY_TIME);
      }
      setIsRunning(false);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRunning, timeLeft, mode, onSessionComplete]);

  if (!isOpen) return null;

  const toggleRun = () => {
    sounds.playClick();
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    sounds.playClick();
    setIsRunning(false);
    setTimeLeft(mode === 'study' ? STUDY_TIME : BREAK_TIME);
  };

  const switchMode = (newMode: 'study' | 'break') => {
    sounds.playClick();
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(newMode === 'study' ? STUDY_TIME : BREAK_TIME);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const currentDuration = mode === 'study' ? STUDY_TIME : BREAK_TIME;
  const progressPct = ((currentDuration - timeLeft) / currentDuration) * 100;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="clay-card w-full max-w-sm p-6 relative text-center animate-in zoom-in-95 duration-200"
      >
        <button
          onClick={() => {
            sounds.playClick();
            onClose();
          }}
          className="absolute top-4 left-4 p-2 rounded-xl clay-btn text-slate-400 hover:text-slate-700"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 mb-2">
          <Clock className="w-4 h-4" />
          <span>مؤقت المذاكرة والتركيز (بومودورو)</span>
        </div>

        {/* Mode Switcher */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-xl clay-inset mb-6">
          <button
            onClick={() => switchMode('study')}
            className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode === 'study' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>جلسة تركيز (25د)</span>
          </button>
          <button
            onClick={() => switchMode('break')}
            className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              mode === 'break' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Coffee className="w-3.5 h-3.5 text-emerald-400" />
            <span>استراحة (5د)</span>
          </button>
        </div>

        {/* Circular Clock Display */}
        <div className="w-44 h-44 mx-auto rounded-full clay-inset flex flex-col items-center justify-center relative mb-6">
          <span className="text-4xl font-black text-slate-900 dark:text-white font-['JetBrains_Mono'] tracking-wider">
            {formattedTime}
          </span>
          <span className="text-xs text-slate-500 font-bold mt-1">
            {mode === 'study' ? 'وقت المذاكرة والحل' : 'استراحة وقهوة'}
          </span>

          {/* Bottom subtle progress line */}
          <div className="absolute bottom-6 w-20 h-1 bg-slate-300 dark:bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-indigo-500 transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={toggleRun}
            className={`px-6 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 text-white shadow-md transition-all ${
              isRunning ? 'bg-amber-600 hover:bg-amber-700' : 'clay-primary'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>إيقاف مؤقت</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>ابدأ الجلسة</span>
              </>
            )}
          </button>

          <button
            onClick={resetTimer}
            title="إعادة التعيين"
            className="p-2.5 rounded-xl clay-btn text-slate-600 dark:text-slate-300"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
