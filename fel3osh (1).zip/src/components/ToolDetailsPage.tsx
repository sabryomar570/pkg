import React, { useState, useEffect } from 'react';
import { ArrowLeft, Play, CheckCircle2, ShieldCheck, Zap, Sparkles, Monitor, UserCheck, Flame, Eye, X, Heart, Star, ThumbsUp, SendHorizonal } from 'lucide-react';
import { WhatsAppIcon, TelegramIcon } from './SocialIcons';
import { toolVideos, toolScreenshots, toolScreenshotsRow1, toolScreenshotsRow2, examSolverFaqs, initialStudentReviews } from '../data/chaptersData';
import { isApprovedReview, toggleLikeCount } from '../utils/rules';
import confetti from 'canvas-confetti';

interface ToolDetailsPageProps {
  onBackToLibrary: () => void;
}

interface ReviewItem {
  id: string;
  author: string;
  grade: string;
  rating: number;
  text: string;
  time: string;
}

// مكون الصورة مع هيكل التحميل (UX Skeleton / Shimmer Loader) للشبكات الضعيفة
const ImageWithSkeleton: React.FC<{
  src: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
}> = ({ src, alt, className = '', loading = 'lazy' }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-200 dark:bg-slate-800">
      {!isLoaded && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-gradient-to-r from-slate-200 via-slate-100 to-slate-200 dark:from-slate-800 dark:via-slate-700 dark:to-slate-800 animate-pulse p-2 text-center">
          <div className="w-5 h-5 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin mb-1 opacity-80" />
          <span className="text-[9px] font-bold font-ios text-slate-400 dark:text-slate-500">جاري التحميل...</span>
        </div>
      )}
      <img
        src={src}
        alt={alt}
        loading={loading}
        onLoad={() => setIsLoaded(true)}
        className={`${className} transition-opacity duration-300 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
      />
    </div>
  );
};

export const ToolDetailsPage: React.FC<ToolDetailsPageProps> = ({ onBackToLibrary }) => {
  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/OmarSaabry';

  const [activeVideoIdx, setActiveVideoIdx] = useState(0);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isCardsExpanded, setIsCardsExpanded] = useState(false);

  // Like counter starting at 648 as requested!
  const [likesCount, setLikesCount] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fel3osh_tool_likes');
      return saved ? parseInt(saved, 10) : 648;
    }
    return 648;
  });
  const [hasLiked, setHasLiked] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('fel3osh_has_liked') === 'true';
    }
    return false;
  });

  // Student Reviews State
  const [reviews, setReviews] = useState<ReviewItem[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fel3osh_approved_reviews');
      return saved ? JSON.parse(saved) : initialStudentReviews;
    }
    return initialStudentReviews;
  });

  const [newAuthor, setNewAuthor] = useState('');
  const [newGrade, setNewGrade] = useState('تانية بكالوريا');
  const [newRating, setNewRating] = useState(5);
  const [newText, setNewText] = useState('');
  const [feedbackStatus, setFeedbackStatus] = useState<string | null>(null);

  const handleToggleLike = () => {
    const { nextCount, nextLiked } = toggleLikeCount(likesCount, hasLiked);
    setLikesCount(nextCount);
    setHasLiked(nextLiked);
    localStorage.setItem('fel3osh_tool_likes', String(nextCount));
    localStorage.setItem('fel3osh_has_liked', String(nextLiked));

    if (nextLiked) {
      try {
        confetti({
          particleCount: 25,
          spread: 45,
          origin: { y: 0.6 },
          colors: ['#ef4444', '#ec4899', '#8b5cf6'],
          disableForReducedMotion: true,
        });
      } catch {}
    }
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newText.trim()) return;

    // Filter rule: Negative reviews (< 4 stars) are politely accepted but NOT displayed publicly!
    const isPositive = isApprovedReview(newRating);

    if (isPositive) {
      const newRev: ReviewItem = {
        id: 'rev-' + Date.now(),
        author: newAuthor.trim(),
        grade: newGrade,
        rating: newRating,
        text: newText.trim(),
        time: 'الآن',
      };
      const updated = [newRev, ...reviews];
      setReviews(updated);
      localStorage.setItem('fel3osh_approved_reviews', JSON.stringify(updated));
      setFeedbackStatus('تم نشر تقييمك بنجاح، شكراً لرأيك يا بطل! 🌟');
    } else {
      // Negative review is kept hidden ("لو التقيم سلبي او ماشابه لا يتم عرضه")
      setFeedbackStatus('شكراً لملاحظتك، تم إرسال رسالتك مباشرة لعمر صبري لمتابعتها! 🤍');
    }

    setNewAuthor('');
    setNewText('');
    setNewRating(5);

    setTimeout(() => setFeedbackStatus(null), 5000);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 sm:py-12 text-right animate-in fade-in duration-300">
      {/* 1. Top Breadcrumb & Back Button */}
      <div className="flex items-center justify-between mb-6 sm:mb-8">
        <button
          onClick={onBackToLibrary}
          className="clay-btn py-2 px-4 sm:px-5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 text-indigo-600 dark:text-sky-400 hover:text-indigo-700 font-ios"
        >
          <ArrowLeft className="w-4 h-4 rotate-180" />
          <span>الرجوع لمكتبة الحلول</span>
        </button>

        <div className="text-xs sm:text-sm font-semibold font-decorative text-slate-500 dark:text-slate-400">
          تطوير: <span className="text-indigo-600 dark:text-sky-400 font-bold">عُـمـر صَـبـري</span>
        </div>
      </div>

      {/* 2. Main Pitch Hero Banner (الفكرة باختصار من غير لف ودوران) */}
      <div className="clay-card p-4 sm:p-8 mb-6 sm:mb-8 relative overflow-hidden border border-white/80 dark:border-white/10">
        <div className="max-w-4xl space-y-3 sm:space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full clay-inset text-amber-700 dark:text-amber-300 text-xs font-bold font-decorative">
              <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span>صلي على النبي بقى 🤍</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full clay-inset text-slate-700 dark:text-slate-300 text-xs font-bold font-decorative">
              <span className="text-indigo-600 dark:text-sky-400 font-bold">𝕯𝖊𝖛 : عُـمـر صَـبـري</span>
            </div>
          </div>

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black font-decorative text-slate-900 dark:text-white leading-[1.3] tracking-tight">
            الفكرة باختصار{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-sky-500 to-emerald-500">
              (من غير لف ودوران)
            </span>
          </h1>

          <div className="p-3.5 sm:p-5 rounded-2xl clay-inset text-slate-700 dark:text-slate-200 text-xs sm:text-base leading-relaxed space-y-2.5">
            <p className="font-bold font-decorative text-slate-900 dark:text-white text-sm sm:text-lg">
              بص يا مدير.. إحنا عارفين الحوار وما فيه؛
            </p>
            <p className="font-ios text-xs sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
              قدامك 87 فصل وأكتر من 600 سؤال وكود مطلوبين منك، يا إما تقعد تسحل نفسك ليل نهار نسخ ولصق وتدعك عينك وتضيع يومك كله..{' '}
              <span className="font-bold text-indigo-600 dark:text-sky-400">يا إما تشغل دماغك!</span>
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="font-bold text-xs sm:text-lg font-decorative shimmer-text">
                عملتلك أداة بتخلّص الليلة كلها في 4 دقايق بس! ✨
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-2xl clay-card bg-amber-500/10 dark:bg-amber-400/10 text-xs font-black shadow-md border border-amber-400/50">
                <span className="text-xs">🏷️</span>
                <span className="text-amber-600 dark:text-amber-300 font-black italic -skew-x-12 text-xs sm:text-sm font-mono tracking-wider">
                  50ج
                </span>
                <span className="text-xs">⚡</span>
              </span>
            </div>
          </div>

          {/* Quick CTA Buttons & Interactive Like Counter */}
          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="clay-whatsapp px-4 sm:px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-md text-white font-ios"
            >
              <WhatsAppIcon className="w-4 h-4" />
              <span>عاوز اشترك يخويااااا (واتساب مباشر)</span>
            </a>

            <a
              href={TELEGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="clay-telegram px-3.5 sm:px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 text-white font-ios"
            >
              <TelegramIcon className="w-4 h-4" />
              <span>تليجرام @OmarSaabry</span>
            </a>

            {/* Interactive Like Counter Badge (Starts at 648) */}
            <button
              onClick={handleToggleLike}
              className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all font-ios ${
                hasLiked
                  ? 'bg-rose-500 text-white shadow-md'
                  : 'clay-btn text-slate-700 dark:text-slate-300 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${hasLiked ? 'fill-white text-white' : 'text-rose-500'}`} />
              <span>{hasLiked ? 'أعجبك' : 'إعجاب'}</span>
              <span className="font-mono px-1.5 py-0.5 rounded-lg bg-black/10 dark:bg-white/10 font-bold">
                {likesCount}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. The Mechanism Breakdown (مضغوطة وأنيقة بدون مساحة زائدة) */}
      <div className="clay-card p-4 sm:p-6 mb-6 sm:mb-8 border border-white/80 dark:border-white/10">
        <div className="text-right max-w-3xl mb-3 sm:mb-4">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-xl clay-inset text-indigo-600 dark:text-sky-300 text-[11px] font-bold mb-1 font-decorative">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>الأمان ومحاكاة السلوك البشري 100%</span>
          </div>
          <h2 className="text-base sm:text-xl font-black font-decorative text-slate-900 dark:text-white">
            الميكانيزم شغال إزاي؟ (ليه المنصة تحلف إنه أنت؟)
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios mt-0.5">
            مش سكربت أعمى بيرمي حلول؛ دي خوارزمية بتحاكي حركة وتفكير الطالب الواقعي بدقة.
          </p>
        </div>

        {/* 3 Core Mechanism Steps Compact Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Step 1 */}
          <div className="clay-inset p-3 rounded-2xl space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl clay-apple-blue flex items-center justify-center text-white font-bold text-xs shadow-sm font-mono shrink-0">
                1
              </div>
              <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white">
                تسجيل الدخول كأنه أنت
              </h3>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios leading-normal">
              بياخد بياناتك ويسجل دخول كأنه أنت بالظبط وبنفس بروتوكول جهازك بدون ملاحظة نشاط غريب.
            </p>
          </div>

          {/* Step 2 */}
          <div className="clay-inset p-3 rounded-2xl space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-sm font-mono shrink-0">
                2
              </div>
              <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white">
                محاكاة السلوك البشري
              </h3>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios leading-normal">
              بيكتب بالراحة ويضغط في الأماكن الصح وينقل بنعومة، والمنصة تطلع تقرير إنك أينشتاين!
            </p>
          </div>

          {/* Step 3 */}
          <div className="clay-inset p-3 rounded-2xl space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl clay-whatsapp flex items-center justify-center text-white font-bold text-xs shadow-sm font-mono shrink-0">
                3
              </div>
              <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white">
                إنهاء الليلة في 4 دقائق
              </h3>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios leading-normal">
              الامتحان كله بيتحل بـ 50ج فقط في أقل من 4 دقايق وأنت مروّق جمجمتك وشايف التقرير 100%.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Vertical Phone / Reels / TikTok UX Video Demonstrations with Breathing Room */}
      <div className="clay-card p-5 sm:p-10 mb-8 sm:mb-10 border border-white/80 dark:border-white/10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6 sm:mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl clay-inset text-indigo-600 dark:text-sky-300 text-xs font-bold mb-1 font-decorative">
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>فيديوهات الشاشة الحقيقية أثناء الحل</span>
            </div>
            <h2 className="text-xl sm:text-3xl font-black font-ios text-slate-900 dark:text-white">
              شاهد تسجيل الشاشة الحقيقي للأداة أثناء حل الامتحان
            </h2>
          </div>

          {/* Video Selector Tabs */}
          <div className="flex items-center gap-2 p-1.5 rounded-2xl clay-inset text-xs font-bold font-decorative">
            {toolVideos.map((vid, idx) => (
              <button
                key={idx}
                onClick={() => setActiveVideoIdx(idx)}
                className={`px-3 py-1.5 rounded-xl transition-all ${
                  activeVideoIdx === idx
                    ? 'clay-apple-blue text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {vid.tag}
              </button>
            ))}
          </div>
        </div>

        {/* Vertical TikTok / Reels Format (9:16) with generous side breathing room */}
        <div className="py-4 sm:py-6 flex flex-col items-center">
          <div className="w-full max-w-[310px] sm:max-w-[340px] rounded-[2.5rem] p-3 sm:p-4 clay-inset bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xl relative">
            {/* Phone Top Speaker & Camera Notch Detail */}
            <div className="w-24 h-4 bg-slate-300 dark:bg-slate-800 rounded-full mx-auto mb-2 flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-700" />
              <span className="w-8 h-1.5 rounded-full bg-slate-400/80 dark:bg-slate-700" />
            </div>

            {/* Vertical Video Element */}
            <div className="aspect-[9/16] w-full rounded-2xl overflow-hidden bg-black relative flex items-center justify-center shadow-inner">
              <video
                key={toolVideos[activeVideoIdx].src}
                controls
                playsInline
                preload="metadata"
                className="w-full h-full object-cover"
                poster="/media/screenshots/Screenshot_20261031-100300.jpg"
              >
                <source src={toolVideos[activeVideoIdx].src} type="video/mp4" />
                متصفحك لا يدعم تشغيل الفيديو.
              </video>
            </div>

            {/* Bottom Caption */}
            <div className="pt-3 px-1 text-right">
              <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white">
                {toolVideos[activeVideoIdx].title}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-ios mt-1 leading-relaxed">
                {toolVideos[activeVideoIdx].description}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Four-Track Continuous Marquee Gallery / Expanded Interactive Cards */}
      <div className="clay-card p-5 sm:p-10 mb-8 sm:mb-10 border border-white/80 dark:border-white/10 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="text-right max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl clay-inset text-indigo-600 dark:text-sky-300 text-xs font-bold mb-1 font-decorative">
              <Eye className="w-3.5 h-3.5" />
              <span>معرض الإثباتات والدرجات النهائية 100%</span>
            </div>
            <h2 className="text-xl sm:text-3xl font-black font-decorative text-slate-900 dark:text-white">
              معرض إثباتات وتجارب الطلاب — تقفيل 100% بالهاتف
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-ios mt-1">
              تدفق استعراضي مستمر لنتائج تقفيل المستويات والامتحانات. اضغط على أي صورة لتثبيت التدفق والانتشار كبطاقات تفاعلية لمطالعتها بأريحية!
            </p>
          </div>

          <button
            onClick={() => setIsCardsExpanded((prev) => !prev)}
            className="clay-btn px-4 py-2.5 rounded-2xl text-xs font-bold text-indigo-600 dark:text-sky-400 font-decorative flex items-center justify-center gap-2 shrink-0 shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>{isCardsExpanded ? 'المعاودة للتدفق المستمر ⚡' : 'الانتشار كبطاقات تفاعلية 🎴'}</span>
          </button>
        </div>

        {isCardsExpanded ? (
          /* Expanded Cards Grid Mode */
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 animate-in fade-in duration-300 pt-2">
            {toolScreenshots.map((item, idx) => (
              <div
                key={`grid-${idx}`}
                onClick={() => setSelectedImage(item.src)}
                className="clay-btn p-2 rounded-2xl cursor-pointer group hover:scale-[1.03] transition-all text-right overflow-hidden border border-indigo-200/40 dark:border-indigo-800/40"
              >
                <div className="aspect-[9/16] rounded-xl overflow-hidden bg-slate-900 relative mb-2">
                  <ImageWithSkeleton
                    src={item.src}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-bold font-ios p-2 text-center z-20">
                    معاينة مكبرة 🔍
                  </div>
                </div>
                <div className="px-1">
                  <div className="text-[11px] font-bold font-decorative text-slate-900 dark:text-white truncate">
                    {item.title}
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 font-ios line-clamp-1 mt-0.5">
                    {item.description}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* 2 Horizontal Continuous Flowing Marquee Rows (Contiguous Film Ribbon with UX Skeleton) */
          <div className="relative w-full overflow-hidden py-2 space-y-2 marquee-fade-edges">


            {/* Row 1: Flowing Right-to-Left Continuously (100% Contiguous Film Strip) */}
            <div className="animate-marquee-row-rtl flex items-center gap-2">
              {[...toolScreenshotsRow1, ...toolScreenshotsRow1].map((item, idx) => (
                <div
                  key={`row1-${idx}`}
                  onClick={() => {
                    setSelectedImage(item.src);
                    setIsCardsExpanded(true);
                  }}
                  className="w-32 sm:w-40 shrink-0 clay-btn p-1.5 rounded-xl cursor-pointer group hover:scale-[1.02] transition-all text-right overflow-hidden shadow-sm"
                >
                  <div className="aspect-[9/16] rounded-lg overflow-hidden bg-slate-900 relative mb-1">
                    <ImageWithSkeleton
                      src={item.src}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="px-0.5 pb-0.5">
                    <div className="text-[10px] font-bold font-decorative text-slate-900 dark:text-white truncate">
                      {item.title}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Row 2: Flowing Left-to-Right Continuously (100% Contiguous Film Strip) */}
            <div className="animate-marquee-row-ltr flex items-center gap-2">
              {[...toolScreenshotsRow2, ...toolScreenshotsRow2].map((item, idx) => (
                <div
                  key={`row2-${idx}`}
                  onClick={() => {
                    setSelectedImage(item.src);
                    setIsCardsExpanded(true);
                  }}
                  className="w-32 sm:w-40 shrink-0 clay-btn p-1.5 rounded-xl cursor-pointer group hover:scale-[1.02] transition-all text-right overflow-hidden shadow-sm"
                >
                  <div className="aspect-[9/16] rounded-lg overflow-hidden bg-slate-900 relative mb-1">
                    <ImageWithSkeleton
                      src={item.src}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="px-0.5 pb-0.5">
                    <div className="text-[10px] font-bold font-decorative text-slate-900 dark:text-white truncate">
                      {item.title}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          onClick={() => setSelectedImage(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-sm sm:max-w-md w-full max-h-[90vh] rounded-3xl overflow-hidden clay-card p-3 bg-slate-900 text-white flex flex-col"
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <ImageWithSkeleton
              src={selectedImage}
              alt="Screenshot full view"
              className="w-full h-auto max-h-[82vh] object-contain rounded-2xl"
            />
          </div>
        </div>
      )}

      {/* 6. Student Reviews Wall & Submission Form (مضغوطة ومصغرة للنصف بأسلوب ممتازة) */}
      <div className="clay-card p-4 sm:p-6 mb-6 sm:mb-8 border border-white/80 dark:border-white/10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 mb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-xl clay-inset text-amber-700 dark:text-amber-300 text-[11px] font-bold mb-1 font-decorative">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>تجارب الطلاب الحقيقية</span>
            </div>
            <h2 className="text-base sm:text-xl font-black font-decorative text-slate-900 dark:text-white">
              آراء الطلاب اللي جربوا الأداة وخلصوا امتحاناتهم
            </h2>
          </div>

          <div className="flex items-center gap-1 text-amber-500 text-xs font-bold clay-inset px-2.5 py-1 rounded-xl font-ios">
            <span>5.0</span>
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <span className="text-[10px] text-slate-500">({reviews.length} تقييم)</span>
          </div>
        </div>

        {/* Existing Approved Reviews Grid - Compact Half Size */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-5">
          {reviews.map((rev) => (
            <div key={rev.id} className="clay-inset p-2.5 sm:p-3 rounded-xl space-y-1 text-right">
              <div className="flex items-center justify-between gap-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full clay-apple-blue flex items-center justify-center text-white text-[10px] font-bold font-ios shrink-0">
                    {rev.author.charAt(0)}
                  </div>
                  <div>
                    <span className="text-xs font-bold font-ios text-slate-900 dark:text-white block leading-tight">
                      {rev.author}
                    </span>
                    <span className="text-[9px] text-slate-500 dark:text-slate-400 font-decorative block leading-none">
                      {rev.grade}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-0.5 text-amber-400 shrink-0">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-2.5 h-2.5 fill-current" />
                  ))}
                </div>
              </div>

              <p className="text-[11px] sm:text-xs text-slate-700 dark:text-slate-300 font-ios leading-normal pt-0.5">
                "{rev.text}"
              </p>
              <div className="text-[9px] text-slate-400 font-ios text-left">
                {rev.time}
              </div>
            </div>
          ))}
        </div>

        {/* Add Student Review Form - Compact */}
        <div className="p-3 sm:p-4 rounded-2xl clay-inset border border-slate-200/60 dark:border-slate-800/60">
          <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white mb-1">
            اتعاملت معانا؟ شاركنا رأيك وتجربتك مع الأداة:
          </h3>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 font-ios mb-3">
            رأيك يهمنا لمساعدة زمايلك الطلاب في أولى وتانية بكالوريا.
          </p>

          {feedbackStatus && (
            <div className="mb-3 p-2 rounded-lg clay-card text-[11px] font-bold text-emerald-700 dark:text-emerald-300 font-ios animate-in fade-in">
              {feedbackStatus}
            </div>
          )}

          <form onSubmit={handleReviewSubmit} className="space-y-2.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-0.5 font-ios">
                  اسمك أو كنيتك:
                </label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="مثال: يوسف الشريف"
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs font-ios clay-card border-none outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-0.5 font-ios">
                  السنة الدراسية:
                </label>
                <select
                  value={newGrade}
                  onChange={(e) => setNewGrade(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs font-ios clay-card border-none outline-none text-slate-800 dark:text-slate-100"
                >
                  <option value="أولى بكالوريا">أولى بكالوريا (جافا)</option>
                  <option value="تانية بكالوريا">تانية بكالوريا (جافا متقدمة)</option>
                  <option value="تانية بكالوريا - بايثون">تانية بكالوريا - بايثون</option>
                  <option value="تانية بكالوريا - الثقافة المالية">تانية بكالوريا - الثقافة المالية</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-0.5 font-ios">
                تقييمك للأداة:
              </label>
              <div className="flex items-center gap-1 py-0.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setNewRating(star)}
                    className="p-1 rounded-md clay-btn"
                  >
                    <Star
                      className={`w-3.5 h-3.5 ${
                        star <= newRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-[11px] font-bold text-slate-500 font-ios mr-1.5">
                  {newRating} من 5 نجوم
                </span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-0.5 font-ios">
                تعليقك ورأيك في تجربة الحل:
              </label>
              <textarea
                required
                rows={2}
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder="اكتب تجربتك وإزاي الأداة ساعدتك..."
                className="w-full p-2 rounded-lg text-xs font-ios clay-card border-none outline-none text-slate-800 dark:text-slate-100 resize-none"
              />
            </div>

            <button
              type="submit"
              className="clay-apple-blue py-2 px-5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 text-white font-ios shadow-sm"
            >
              <SendHorizonal className="w-3.5 h-3.5" />
              <span>إرسال التقييم</span>
            </button>
          </form>
        </div>
      </div>

      {/* 7. FAQ Section */}
      <div className="clay-card p-4 sm:p-6 mb-6 sm:mb-8 border border-white/80 dark:border-white/10">
        <h2 className="text-base sm:text-xl font-black font-ios text-slate-900 dark:text-white mb-4">
          الأسئلة اللي في بالك وإجابتها ع البلاطة:
        </h2>

        <div className="space-y-3">
          {examSolverFaqs.map((faq, idx) => (
            <div key={idx} className="clay-inset p-3 sm:p-4 rounded-xl text-right space-y-1">
              <h3 className="text-xs sm:text-sm font-bold font-ios text-slate-900 dark:text-white flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                <span>{faq.q}</span>
              </h3>
              <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 font-ios leading-relaxed pr-3">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* 8. Final Conversion CTA with Direct WhatsApp & Telegram */}
      <div className="clay-card p-5 sm:p-8 text-center bg-gradient-to-r from-indigo-50/90 via-sky-50/80 to-purple-50/90 dark:from-indigo-950/40 dark:via-sky-950/30 dark:to-purple-950/30 border border-white/80 dark:border-white/10">
        <h2 className="text-xl sm:text-3xl font-black font-decorative text-slate-900 dark:text-white mb-2">
          عايز تشترك وتريح جمجمتك؟
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-ios max-w-xl mx-auto mb-4 leading-relaxed">
          اضغط زرار "كلمني" على الواتساب، الرسالة هتتكتب لوحدها: "عاوز اشترك يخويااااا"، وأنا هظبطك في ثانية، أو كلمني دغري ع التليجرام: @OmarSaabry.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3">
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-whatsapp inline-flex items-center gap-2 px-5 sm:px-6 py-3 rounded-2xl text-xs sm:text-sm font-bold shadow-lg hover:scale-105 active:scale-95 transition-all text-white font-ios"
          >
            <WhatsAppIcon className="w-4 h-4 shrink-0" />
            <span>كلمني واتساب: عاوز اشترك يخويااااا</span>
          </a>

          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-telegram inline-flex items-center gap-2 px-4 sm:px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold shadow-md hover:scale-105 active:scale-95 transition-all text-white font-ios"
          >
            <TelegramIcon className="w-4 h-4 shrink-0" />
            <span>تليجرام @OmarSaabry</span>
          </a>
        </div>
      </div>
    </div>
  );
};
