import React, { useState, useRef } from 'react';
import { ChevronLeft, ChevronRight, X, GripVertical } from 'lucide-react';
import { WhatsAppIcon, TelegramIcon } from './SocialIcons';

export const DraggableContactWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [side, setSide] = useState<'right' | 'left'>('left');
  const [topPos, setTopPos] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      return Math.round(window.innerHeight * 0.65);
    }
    return 380;
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartYRef = useRef(0);
  const initialTopRef = useRef(380);
  const dragStartXRef = useRef(0);
  const totalMovementRef = useRef(0);

  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/OmarSaabry';

  const handlePointerDown = (e: React.PointerEvent) => {
    // Only primary touch / left click
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    
    setIsDragging(true);
    dragStartYRef.current = e.clientY;
    dragStartXRef.current = e.clientX;
    initialTopRef.current = topPos;
    totalMovementRef.current = 0;

    const target = e.currentTarget as HTMLElement;
    try {
      target.setPointerCapture(e.pointerId);
    } catch {}
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dy = e.clientY - dragStartYRef.current;
    const dx = e.clientX - dragStartXRef.current;
    totalMovementRef.current = Math.hypot(dx, dy);

    const newY = initialTopRef.current + dy;
    const clampedY = Math.max(60, Math.min(window.innerHeight - 120, newY));
    setTopPos(clampedY);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);

    const target = e.currentTarget as HTMLElement;
    try {
      if (target.hasPointerCapture(e.pointerId)) {
        target.releasePointerCapture(e.pointerId);
      }
    } catch {}

    // Snap to nearest screen side edge (left or right)
    const midScreen = window.innerWidth / 2;
    const nextSide = e.clientX < midScreen ? 'left' : 'right';
    setSide(nextSide);

    // If movement was minimal (< 6px), treat as a tap/click to toggle open/fold
    if (totalMovementRef.current < 6) {
      setIsOpen((prev) => !prev);
    } else {
      // If dragged, automatically fold into the edge smoothly
      setIsOpen(false);
    }
  };

  return (
    <div
      style={{
        top: `${topPos}px`,
        [side]: 0,
        touchAction: 'none',
      }}
      className={`fixed z-50 select-none ${
        isDragging ? 'cursor-grabbing scale-105 transition-none' : 'cursor-grab transition-all duration-300'
      }`}
    >
      {isOpen ? (
        /* Expanded Floating Contact Card */
        <div
          className={`clay-card p-3 rounded-2xl bg-white/95 dark:bg-slate-900/95 border border-white/80 dark:border-white/10 shadow-2xl backdrop-blur-xl flex flex-col gap-2 max-w-[210px] text-right ${
            side === 'right'
              ? 'mr-2 sm:mr-3 slide-in-from-right'
              : 'ml-2 sm:ml-3 slide-in-from-left'
          }`}
        >
          <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800/60 pb-1.5 gap-2">
            {/* Drag Handle Bar */}
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              title="اسحب لنقل أيقونة التواصل"
              className="p-1 rounded-lg clay-inset cursor-grab text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 shrink-0 touch-none"
            >
              <GripVertical className="w-3.5 h-3.5" />
            </div>

            <span className="text-[11px] font-bold font-mono text-indigo-600 dark:text-sky-400 tracking-wider truncate">
              DEV OMAR SABRY
            </span>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg clay-btn text-slate-400 hover:text-slate-700 dark:hover:text-white shrink-0"
              aria-label="إغلاق نافذة التواصل"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-whatsapp py-2 px-2.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-2 text-white font-ios shadow-sm transition-transform hover:scale-[1.02]"
          >
            <WhatsAppIcon className="w-4 h-4 shrink-0" />
            <span>واتساب مباشر</span>
          </a>

          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="clay-telegram py-2 px-2.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-2 text-white font-ios shadow-sm transition-transform hover:scale-[1.02]"
          >
            <TelegramIcon className="w-4 h-4 shrink-0" />
            <span>تليجرام @OmarSaabry</span>
          </a>
        </div>
      ) : (
        /* Folded Floating Side Button - Peeking from Edge */
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="group flex items-center touch-none cursor-grab active:cursor-grabbing"
          title="انقر للتواصل أو اسحب لنقل الأيقونة"
        >
          <div
            className={`clay-apple-blue py-2 px-2.5 shadow-xl flex items-center gap-1.5 text-white hover:scale-105 transition-all duration-200 text-xs font-bold border-y border-white/30 ${
              side === 'right'
                ? 'rounded-l-2xl rounded-r-none border-l'
                : 'rounded-r-2xl rounded-l-none border-r'
            }`}
          >
            {side === 'right' ? (
              <ChevronLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            )}

            <div className="flex items-center gap-1 pointer-events-none">
              <WhatsAppIcon className="w-3.5 h-3.5" />
              <TelegramIcon className="w-3.5 h-3.5" />
            </div>

            <span className="text-[10px] font-bold font-decorative hidden sm:inline-block pr-0.5 pointer-events-none">
              تواصل
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
