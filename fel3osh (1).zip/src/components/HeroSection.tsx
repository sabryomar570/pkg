import React from 'react';
import { ArrowDown, Zap, CheckCircle2, ShieldCheck, Sparkles, BookOpen } from 'lucide-react';
import { WhatsAppIcon, TelegramIcon } from './SocialIcons';

interface HeroSectionProps {
  onScrollToLibrary: () => void;
  onOpenToolDetails: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onScrollToLibrary,
  onOpenToolDetails,
}) => {
  const WHATSAPP_URL =
    'https://wa.me/201550324450?text=' + encodeURIComponent('عاوز اشترك يخويااااا');
  const TELEGRAM_URL = 'https://t.me/OmarSaabry';

  return (
    <section className="relative overflow-hidden py-4 sm:py-8 px-3 sm:px-6">
      <div className="max-w-6xl mx-auto clay-card p-5 sm:p-10 relative overflow-hidden text-right border border-white/80 dark:border-white/10">
        {/* Subtle Ambient Apple Blur Glow in Corner */}
        <div className="absolute top-0 left-0 w-80 h-80 bg-gradient-to-br from-indigo-500/10 via-sky-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6 sm:gap-8">
          {/* Main Content Side */}
          <div className="flex-1 space-y-3.5 sm:space-y-4">
            {/* Top Badges Row */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Badge: صلي على النبي بقى */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-2xl clay-inset text-xs font-bold text-amber-700 dark:text-amber-300 font-decorative">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span>صلي على النبي بقى 🤍</span>
              </div>

              {/* Tag: 𝕯𝖊𝖛 : عُـمـر صَـبـري */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-2xl clay-inset text-xs font-bold text-indigo-600 dark:text-sky-300 font-decorative">
                <span>𝕯𝖊𝖛 : عُـمـر صَـبـري</span>
              </div>

              {/* Tag: منصة Fel3osh */}
              <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-2xl clay-inset text-xs font-bold text-emerald-700 dark:text-emerald-300 font-decorative">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                <span>حلول معتمدة 100%</span>
              </div>
            </div>

            {/* Main Punchy Headline in Decorative Arabic Calligraphy Font */}
            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black font-decorative text-slate-900 dark:text-white leading-[1.3] sm:leading-[1.35] tracking-tight">
              بص يا مدير.. إحنا عارفين الحوار وما فيه،
              <span className="block mt-1 shimmer-text">
                عملتلك أداة بتخلّص الليلة كلها في 4 دقايق بس! ✨
              </span>
            </h1>

            {/* Expressive Display Paragraph */}
            <p className="text-xs sm:text-sm md:text-base text-slate-700 dark:text-slate-200 font-medium leading-relaxed max-w-2xl font-ios">
              قدامك 87 فصل وأكتر من 600 سؤال وكود مطلوبين منك في أولى وتانية بكالوريا؛ يا إما تقعد تسحل نفسك ليل نهار نسخ ولصق وتدعك عينك وتضيع يومك كله.. يا إما تشغل دماغك! جهزتلك مكتبة حلول نموذجية مجانية بالكامل، وعملتلك أداة ذكية بتدخل وتحل الامتحان بمحاكاة بشرية تامة والمنصة تحلف إنك الطالب المجتهد اللي مفيش زيه.
            </p>

            {/* Tactile Highlights Badges with decorative font */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs font-bold text-slate-700 dark:text-slate-300 font-decorative">
              <div className="px-3 py-1.5 rounded-xl clay-inset flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>أولى بكالوريا: 42 مستوى جافا</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl clay-inset flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                <span>تانية بكالوريا: 54 جافا + بايثون + المالية</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl clay-inset flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-sky-500 shrink-0" />
                <span>محاكاة بشرية لا تكشفها المنصة</span>
              </div>
            </div>
          </div>

          {/* Action Callouts Buttons with Deep Apple Claymorphism */}
          <div className="flex flex-col gap-2.5 sm:gap-3 shrink-0 w-full lg:w-72 pt-2 lg:pt-0">
            <button
              onClick={onOpenToolDetails}
              className="clay-apple-blue py-3 sm:py-3.5 px-4 sm:px-5 rounded-2xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg text-white font-ios"
            >
              <Zap className="w-4 h-4 fill-amber-300 text-amber-300 animate-pulse" />
              <span>إزاي الأداة بتحل في 4 دقايق؟</span>
            </button>

            <button
              onClick={onScrollToLibrary}
              className="clay-btn py-2.5 sm:py-3 px-4 sm:px-5 rounded-2xl text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center gap-2 font-ios"
            >
              <BookOpen className="w-4 h-4 text-indigo-600 dark:text-sky-400" />
              <span>تصفح مكتبة الحلول المجانية</span>
              <ArrowDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Quick Chat Strip */}
            <div className="flex items-center gap-2 pt-0.5">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                title="تواصل مباشر على واتساب"
                className="clay-whatsapp flex-1 py-2 sm:py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 text-white font-ios"
              >
                <WhatsAppIcon className="w-4 h-4 shrink-0" />
                <span className="truncate">عاوز اشترك يخويااااا</span>
              </a>

              <a
                href={TELEGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                title="تليجرام @OmarSaabry"
                className="clay-telegram p-2 sm:py-2.5 px-3 rounded-xl flex items-center justify-center text-white shrink-0"
              >
                <TelegramIcon className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
