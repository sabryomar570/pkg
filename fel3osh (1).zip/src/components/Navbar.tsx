import React from 'react';
import { Moon, Sun, BookOpen, Clock, Zap, Sparkles } from 'lucide-react';

interface NavbarProps {
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenTimer: () => void;
  activeView: 'library' | 'toolDetails';
  onSelectView: (view: 'library' | 'toolDetails') => void;
  xp: number;
  level: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  isDark,
  onToggleTheme,
  onOpenTimer,
  activeView,
  onSelectView,
  xp,
  level,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#EEF2F7]/95 dark:bg-[#0A0D14]/95 backdrop-blur-xl border-b border-white/60 dark:border-white/5 transition-colors">
      <div className="max-w-7xl mx-auto px-2.5 sm:px-6 h-13 sm:h-20 flex items-center justify-between gap-1.5 sm:gap-4">
        {/* Brand: Fel3osh */}
        <div
          onClick={() => onSelectView('library')}
          className="cursor-pointer flex items-center gap-1.5 sm:gap-3 shrink-0 group select-none"
        >
          <div className="w-8 h-8 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl clay-card flex items-center justify-center p-1 sm:p-1.5 transform group-hover:scale-105 transition-transform bg-white/80 dark:bg-slate-900/80">
            <img
              src="/icon-192.png"
              alt="Fel3osh"
              className="w-full h-full object-contain rounded-lg sm:rounded-xl"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-base sm:text-2xl font-black font-ios text-slate-900 dark:text-white tracking-tight leading-none">
                Fel3osh
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded-md clay-inset text-indigo-600 dark:text-sky-300 font-bold font-decorative hidden sm:inline-block">
                مكتبة الحلول
              </span>
            </div>
            <div className="text-[10px] sm:text-xs font-semibold text-indigo-600 dark:text-sky-400 font-decorative mt-0.5 leading-none tracking-wide">
              𝕯𝖊𝖛 : عُـمـر صَـبـري
            </div>
          </div>
        </div>

        {/* Apple-style Segmented View Switcher */}
        <nav className="flex items-center gap-0.5 sm:gap-1 p-0.5 sm:p-1 rounded-xl sm:rounded-2xl clay-inset">
          <button
            onClick={() => onSelectView('library')}
            className={`px-2.5 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-sm font-bold rounded-lg sm:rounded-xl transition-all flex items-center gap-1.5 font-ios ${
              activeView === 'library'
                ? 'clay-btn bg-white dark:bg-slate-800 text-indigo-600 dark:text-sky-400 shadow-sm border border-indigo-200/50 dark:border-indigo-500/30'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
            <span>المكتبة</span>
          </button>

          <button
            onClick={() => onSelectView('toolDetails')}
            className={`px-2.5 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-sm font-bold rounded-lg sm:rounded-xl transition-all flex items-center gap-1.5 font-ios ${
              activeView === 'toolDetails'
                ? 'clay-btn bg-white dark:bg-slate-800 text-indigo-600 dark:text-sky-400 shadow-sm border border-indigo-200/50 dark:border-indigo-500/30'
                : 'text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-sky-400'
            }`}
          >
            <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 text-amber-500 fill-amber-500" />
            <span>الأداة</span>
          </button>
        </nav>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Level / XP Pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl clay-inset text-xs font-bold text-slate-700 dark:text-slate-300 font-ios">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>مستوى {level}</span>
            <span className="text-indigo-600 dark:text-sky-400 font-mono">({xp} XP)</span>
          </div>

          {/* Pomodoro Timer Modal Trigger */}
          <button
            onClick={onOpenTimer}
            title="مؤقت التركيز"
            className="p-1.5 sm:p-2.5 rounded-lg sm:rounded-xl clay-btn text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-sky-400"
          >
            <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Theme Mode Switch */}
          <button
            onClick={onToggleTheme}
            title={isDark ? 'الوضع النهاري' : 'الوضع الليلي'}
            className="p-1.5 sm:p-2.5 rounded-lg sm:rounded-xl clay-btn text-slate-600 dark:text-slate-300 hover:text-amber-500"
          >
            {isDark ? <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" /> : <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
