import test from 'node:test';
import assert from 'node:assert/strict';
import { filterChaptersByGrade, isApprovedReview, toggleLikeCount } from './rules';
import { Chapter } from '../types';

test('filterChaptersByGrade restricts bac1 strictly to 42 levels', () => {
  const dummyChapters: Chapter[] = Array.from({ length: 54 }, (_, i) => ({
    num: i + 1,
    qs: [{ q: `Q${i + 1}`, a: 'ans' }],
  }));

  const bac1 = filterChaptersByGrade(dummyChapters, 'bac1');
  assert.equal(bac1.length, 42);
  assert.equal(bac1[bac1.length - 1].num, 42);

  const bac2 = filterChaptersByGrade(dummyChapters, 'bac2');
  assert.equal(bac2.length, 54);
  assert.equal(bac2[bac2.length - 1].num, 54);
});

test('isApprovedReview approves only positive feedback (>= 4 stars)', () => {
  assert.equal(isApprovedReview(5), true);
  assert.equal(isApprovedReview(4), true);
  assert.equal(isApprovedReview(3), false);
  assert.equal(isApprovedReview(2), false);
  assert.equal(isApprovedReview(1), false);
  assert.equal(isApprovedReview(0), false);
});

test('toggleLikeCount increments baseline 648 to 649 and restores to 648', () => {
  const step1 = toggleLikeCount(648, false);
  assert.equal(step1.nextCount, 649);
  assert.equal(step1.nextLiked, true);

  const step2 = toggleLikeCount(step1.nextCount, step1.nextLiked);
  assert.equal(step2.nextCount, 648);
  assert.equal(step2.nextLiked, false);

  // Safety test: does not drop below 648 baseline
  const underflowTest = toggleLikeCount(648, true);
  assert.equal(underflowTest.nextCount, 648);
  assert.equal(underflowTest.nextLiked, false);
});
