import { Chapter, AcademicGrade } from '../types';

/**
 * Filter chapters by academic grade:
 * - Bac 1: Exactly 42 levels of programming (Java)
 * - Bac 2: Levels up to 54
 */
export function filterChaptersByGrade(chapters: Chapter[], grade: AcademicGrade): Chapter[] {
  if (grade === 'bac1') {
    return chapters.filter((c) => c.num <= 42);
  }
  return chapters;
}

/**
 * Positive-only review filter:
 * Only reviews with 4 or 5 stars are approved for public display.
 */
export function isApprovedReview(rating: number): boolean {
  return typeof rating === 'number' && rating >= 4 && rating <= 5;
}

/**
 * Like counter toggle math:
 * Initialized at baseline 648. Prevents dropping below 648.
 */
export function toggleLikeCount(currentLikes: number, wasLiked: boolean): { nextCount: number; nextLiked: boolean } {
  if (!wasLiked) {
    return { nextCount: currentLikes + 1, nextLiked: true };
  }
  return { nextCount: Math.max(648, currentLikes - 1), nextLiked: false };
}
