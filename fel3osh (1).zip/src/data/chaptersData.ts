import { Chapter } from '../types';

export const chaptersJs: Chapter[] = [
  {num:1,qs:[{q:'السؤال الأول',a:'console.log("Hello");',code:true},{q:'السؤال الثاني',a:'console.log("Good morning")',code:true},{q:'السؤال الثالث',a:'console.log("Programming");',code:true},{q:'السؤال الرابع',a:'console.log("Hello");',code:true},{q:'السؤال الخامس',a:'//Write your comments here.',code:true},{q:'السؤال السادس',a:'ضيف علامة التعليق // في بداية السطر الثالث',code:false}]},
  {num:2,qs:[{q:'السؤال الأول',a:'console.log(50 + 100);',code:true},{q:'السؤال الثاني',a:'/',code:true},{q:'السؤال الثالث',a:'console.log(19 + 40);',code:true},{q:'السؤال الرابع',a:'console.log(7 - 2);',code:true},{q:'السؤال الخامس',a:'console.log(15 / 5)',code:true},{q:'السؤال السادس',a:'console.log("Today is the 17th.7 days ago was the " + (17 - 7) + "th.");',code:true},{q:'السؤال السابع',a:'console.log("The answer is " + ( 2 * 5) + ".");',code:true}]},
  {num:3,qs:[{q:'السؤال الأول',a:'let score;',code:true},{q:'السؤال الثاني',a:'console.log(score);',code:true},{q:'السؤال الثالث',a:'let number;',code:true},{q:'السؤال الرابع',a:'let number;\nnumber = 100;',code:true},{q:'السؤال الخامس',a:'console.log(number);',code:true},{q:'السؤال السادس',a:'let number;\nnumber = 3;\nnumber = number + 10;\nconsole.log(number);',code:true}]},
  {num:4,qs:[{q:'السؤال الأول',a:'console.log("Hello");',code:true},{q:'السؤال الثاني',a:'console.log("Hello");',code:true},{q:'السؤال الثالث',a:'// تعليق سطر واحد',code:false},{q:'السؤال الرابع',a:'console.log(5 + 7);',code:true},{q:'السؤال الخامس',a:'*',code:true},{q:'السؤال السادس',a:'console.log("The answer is " + (3 * 5 )+ ".");',code:true},{q:'السؤال السابع',a:'let number;',code:true},{q:'السؤال الثامن',a:'let num;\nnum = 5;\nconsole.log(num);',code:true}]},
  {num:5,qs:[{q:'السؤال الأول',a:'let num = 5;\nconsole.log(num);',code:true},{q:'السؤال الثاني',a:'if (conditional) {\n  processing\n}',code:true},{q:'السؤال الثالث',a:'num == 50',code:true},{q:'السؤال الرابع',a:'let num = 100;\nif (num == 100) {\n  console.log("Correct");\n}',code:true},{q:'السؤال الخامس',a:'false',code:false}]},
  {num:6,qs:[{q:'السؤال الأول',a:'if (conditional) {\n  A\n} else {\n  B\n}',code:true},{q:'السؤال الثاني',a:'let num = 5;\nif (num == 10) {\n  console.log("Win");\n} else {\n  console.log("Lose");\n}',code:true},{q:'السؤال الثالث',a:'num <= 80',code:true},{q:'السؤال الرابع',a:'num > 30',code:true},{q:'السؤال الخامس',a:'score >= 60',code:true}]},
  {num:7,qs:[{q:'السؤال الأول',a:'if (conditional) {\n  A\n} else if (conditional) {\n  B\n}',code:true},{q:'السؤال الثاني',a:'let num = 2;\nif (num == 1) {\n  console.log("One");\n} else if (num == 2) {\n  console.log("Two");\n}',code:true},{q:'السؤال الثالث',a:'else if (score >= 80) {\n  console.log("Pass");\n}',code:true},{q:'السؤال الرابع',a:'Pass',code:false},{q:'السؤال الخامس',a:'let egg = 5;\nif (egg == 0) {\n  console.log("No stock");\n} else if (egg <= 3) {\n  console.log("Low stock");\n} else {\n  console.log("In stock");\n}',code:true}]},
  {num:8,qs:[{q:'السؤال الأول',a:'let num = 7;\nif (num == 7) {\n  console.log("Correct");\n}',code:true},{q:'السؤال الثاني',a:'true',code:false},{q:'السؤال الثالث',a:'score >= 60',code:true},{q:'السؤال الرابع',a:'num < 20',code:true},{q:'السؤال الخامس',a:'let num = 100;\nif (num == 100) {\n  console.log("correct");\n} else {\n  console.log("miss");\n}',code:true},{q:'السؤال السادس',a:'So close',code:false},{q:'السؤال السابع',a:'num <= 3; num >= 6; else',code:true}]},
  {num:9,qs:[{q:'السؤال الأول',a:'A && B',code:true},{q:'السؤال الثاني',a:'A || B',code:true},{q:'السؤال الثالث',a:'السعر العادي',code:false},{q:'السؤال الرابع',a:'a == 5 || b == 10',code:true},{q:'السؤال الخامس',a:'a >= 2 && b >= 3',code:true}]},
  {num:10,qs:[{q:'السؤال الأول',a:'for',code:true},{q:'السؤال الثاني',a:'i++',code:true},{q:'السؤال الثالث',a:'for (let i = 0; i < 10; i++) {\n  Specified process\n}',code:true},{q:'السؤال الرابع',a:'for (let i = 0; i < 5; i++) {\n  console.log("Hello");\n}',code:true},{q:'السؤال الخامس',a:'for (let i = 0; i < 7; i++) {\n  console.log("Hello");\n}',code:true}]},
  {num:11,qs:[{q:'السؤال الأول',a:'A || B',code:true},{q:'السؤال الثاني',a:'A',code:false},{q:'السؤال الثالث',a:'i++',code:true},{q:'السؤال الرابع',a:'for (let i = 0; i < 10; i++) {\n  Process\n}',code:true},{q:'السؤال الخامس',a:'Hello Hello',code:false},{q:'السؤال السادس',a:'for (let i = 0; i < 10; i++) {\n  console.log("Good morning");\n}',code:true},{q:'السؤال السابع',a:'a >= 2 && b >= 3',code:true},{q:'السؤال الثامن',a:'for (let i = 0; i < 3; i++)',code:true}]},
  {num:12,qs:[{q:'السؤال الأول',a:'function calc(num) {\n  processing\n}',code:true},{q:'السؤال الثاني',a:'Math.round(1.8)',code:true},{q:'السؤال الثالث',a:'60',code:false},{q:'السؤال الرابع',a:'15',code:false},{q:'السؤال الخامس',a:'calc(3)',code:true},{q:'السؤال السادس',a:'return result;',code:true}]},
  {num:13,qs:[{q:'السؤال الأول',a:'console.log(Math.random());',code:true},{q:'السؤال الثاني',a:'console.log(Math.floor(10.5));',code:true},{q:'السؤال الثالث',a:'7',code:false},{q:'السؤال الرابع',a:'console.log(Math.round(5.5));\nconsole.log(Math.floor(8.8));',code:true},{q:'السؤال الخامس',a:'Math.random() >= 0.5',code:true},{q:'السؤال السادس',a:'console.log(Math.floor(Math.random() * 10));',code:true}]},
  {num:14,qs:[{q:'السؤال الأول',a:'Math.round(1.8)',code:true},{q:'السؤال الثاني',a:'100',code:false},{q:'السؤال الثالث',a:'console.log(Math.random());',code:true},{q:'السؤال الرابع',a:'12',code:false},{q:'السؤال الخامس',a:'Math.floor(Math.random() * 10)',code:true},{q:'السؤال السادس',a:'function sum(num) {\n  processing\n}',code:true},{q:'السؤال السابع',a:'return result;',code:true},{q:'السؤال الثامن',a:'calc(7)',code:true}]},
  {num:15,qs:[{q:'السؤال الأول',a:'String',code:false},{q:'السؤال الثاني',a:'console.log(typeof "1");',code:true},{q:'السؤال الثالث',a:'false',code:false},{q:'السؤال الرابع',a:'NaN',code:false},{q:'السؤال الخامس',a:'console.log(typeof "7");',code:true}]},
  {num:16,qs:[{q:'السؤال الأول',a:'let num = [5, 10, 15];',code:true},{q:'السؤال الثاني',a:'15',code:false},{q:'السؤال الثالث',a:'num',code:false},{q:'السؤال الرابع',a:'6',code:false},{q:'السؤال الخامس',a:'num.length',code:true}]},
  {num:17,qs:[{q:'السؤال الأول',a:'let',code:true},{q:'السؤال الثاني',a:'let num;\nnum = 3;\nnum = 5;\nconsole.log(num);',code:true},{q:'السؤال الثالث',a:'a != 100',code:true},{q:'السؤال الرابع',a:'while (condition) {\n  process;\n}',code:true},{q:'السؤال الخامس',a:'let money = 1000;\nconst snacks = 230;\nwhile (money > snacks) {\n  money = money - snacks;\n  console.log(money);\n}',code:true},{q:'السؤال السادس',a:'let money = 600;\nlet month = 0;\nwhile (money < 4000) {\n  month++;\n  money += 800;\n}\nconsole.log("Save for " + month + " months");',code:true}]},
  {num:18,qs:[{q:'السؤال الأول',a:'<h1>Hello</h1>',code:true},{q:'السؤال الثاني',a:'<p>Hello</p>',code:true},{q:'السؤال الثالث',a:'br tag',code:false},{q:'السؤال الرابع',a:'ul tag',code:false},{q:'السؤال الخامس',a:'1.Cut ingredients 2.Stir-fry 3.Add seasonings',code:false},{q:'السؤال السادس',a:'<img src="image.png">',code:true},{q:'السؤال السابع',a:'<img alt="This is an image.">',code:true},{q:'السؤال الثامن',a:'<!-- -->',code:true}]},
  {num:19,qs:[{q:'السؤال الأول',a:'h1 {\n  color: red;\n}',code:true},{q:'السؤال الثاني',a:'h1 {\n  color: blue;\n}',code:true},{q:'السؤال الثالث',a:'تغيير لون النص',code:false},{q:'السؤال الرابع',a:'تغيير لون الخلفية',code:false},{q:'السؤال الخامس',a:'يصبح النص عريضًا',code:false},{q:'السؤال السادس',a:'font-size: 10px;',code:true},{q:'السؤال السابع',a:'.dog {\n  color: blue;\n}',code:true},{q:'السؤال الثامن',a:'/* */',code:true}]},
  {num:20,qs:[{q:'السؤال الأول',a:'<p>Good morning</p>',code:true},{q:'السؤال الثاني',a:'br tag',code:false},{q:'السؤال الثالث',a:'<img src="image.png">',code:true},{q:'السؤال الرابع',a:'・strawberry ・cherry ・orange',code:false},{q:'السؤال الخامس',a:'h1 {\n  color: yellow;\n}',code:true},{q:'السؤال السادس',a:'تغيير لون الخلفية',code:false},{q:'السؤال السابع',a:'يصبح الخط عريضًا',code:false},{q:'السؤال الثامن',a:'h3 {\n  color: red;\n}',code:true},{q:'السؤال التاسع',a:'.fish {\n  color: blue;\n}',code:true}]},
  {num:21,qs:[{q:'السؤال الأول',a:'score == 50',code:true},{q:'السؤال الثاني',a:'else if (A < B)',code:true},{q:'السؤال الثالث',a:'A < B',code:true},{q:'السؤال الرابع',a:'score >= 50',code:true},{q:'السؤال الخامس',a:'&&',code:true},{q:'السؤال السادس',a:'||',code:true},{q:'السؤال السابع',a:'numberOfPeople <= 10 || weight <= 800',code:true},{q:'السؤال الثامن',a:'ينتج عنه خطأ',code:false},{q:'السؤال التاسع',a:'let math = 100;\nlet science = 100;\nif (math == 100) {\n  console.log("Math is 100 points");\n  if (science == 100) {\n    console.log("Math and science are 100 points");\n  }\n}',code:true}]},
  {num:22,qs:[{q:'السؤال الأول',a:'for',code:true},{q:'السؤال الثاني',a:'++i',code:true},{q:'السؤال الثالث',a:'for (let i = 0; i < 10; i++) {\n  specified process;\n}',code:true},{q:'السؤال الرابع',a:'let i = 0; i < 3; i++',code:true},{q:'السؤال الخامس',a:'for (let i = 0; i < 7; i++) {\n  console.log("Good morning");\n}',code:true},{q:'السؤال السادس',a:'يؤدي إلى خطأ',code:false},{q:'السؤال السابع',a:'for (let i = 0; i < 5; i++) {\n  console.log("sit-ups");\n  if (i == 4) {\n    console.log("End");\n  }\n}',code:true},{q:'السؤال الثامن',a:'AABA',code:false},{q:'السؤال التاسع',a:'i += 2',code:true}]},
  {num:23,qs:[{q:'السؤال الأول',a:'function move() {\n  Program to Run\n}',code:true},{q:'السؤال الثاني',a:'55',code:false},{q:'السؤال الثالث',a:'30',code:false},{q:'السؤال الرابع',a:'function divide5(total) {\n  let num = total / 5;\n  return num;\n}\nconsole.log(divide5(35));',code:true},{q:'السؤال الخامس',a:'ينتج عنه خطأ',code:false},{q:'السؤال السادس',a:'function goodNight() {\n  let greeting = "Good night!";\n  return greeting;\n}\nconsole.log(goodNight());',code:true},{q:'السؤال السابع',a:'console.log(mul(9, 7));',code:true}]},
  {num:24,qs:[{q:'السؤال الأول',a:'else if (A < B) {\n  console.log("B is larger");\n}',code:true},{q:'السؤال الثاني',a:'&&',code:true},{q:'السؤال الثالث',a:'if (math == 100) {\n  console.log("Science and Math are 100 points");\n}',code:true},{q:'السؤال الرابع',a:'for (let i = 0; i < 7; i++) {\n  console.log("Good morning");\n}',code:true},{q:'السؤال الخامس',a:'ينتج عنه خطأ',code:false},{q:'السؤال السادس',a:'00010',code:false},{q:'السؤال السابع',a:'i += 5',code:true},{q:'السؤال الثامن',a:'console.log(divide3(12345));',code:true},{q:'السؤال التاسع',a:'function move() {\n  Program to Run\n}',code:true},{q:'السؤال العاشر',a:'function mul(num1, num2) {\n  let result = num1 * num2;\n  return result;\n}\nconsole.log(mul(9, 7));',code:true}]},
  {num:25,qs:[{q:'السؤال الأول',a:'8',code:false},{q:'السؤال الثاني',a:'let num = 1;\nfor (let i = 0; i < 5; i++) {\n  num = num * 7;\n}\nconsole.log(num);',code:true},{q:'السؤال الثالث',a:'1→2→3→4→5→6→7→',code:false},{q:'السؤال الرابع',a:'let num = 0;\nfor (let i = 0; i < 6; i++) {\n  num = num + i;\n}\nconsole.log(num);',code:true}]},
  {num:26,qs:[{q:'السؤال الأول',a:'79',code:false},{q:'السؤال الثاني',a:'let scoreList = [52, 60, 79, 82, 66, 59, 88];\nconsole.log(scoreList[5]);',code:true},{q:'السؤال الثالث',a:'let scoreList = [52, 60, 79, 82, 66, 59, 88];\nconsole.log(scoreList[5]);',code:true},{q:'السؤال الرابع',a:'let scoreList = [52, 60, 79, 82, 66, 59, 88];\nconsole.log(scoreList.length);',code:true},{q:'السؤال الخامس',a:'let scoreList = [52, 60, 79, 82, 66, 59, 88];\nfor (let i = 0; i < scoreList.length; i++) {\n  if (scoreList[i] >= 80) {\n    console.log("80 points or higher");\n  }\n}',code:true}]},
  {num:27,qs:[{q:'السؤال الأول',a:'let num = 1;\nfor (let i = 0; i < 3; i++) {\n  num = num * 9;\n}\nconsole.log(num);',code:true},{q:'السؤال الثاني',a:'1234',code:false},{q:'السؤال الثالث',a:'let num = 5040;\nfor (let i = 1; i <= 5; i++) {\n  num = num / i;\n}\nconsole.log(num);',code:true},{q:'السؤال الرابع',a:'scoreList[4]',code:true},{q:'السؤال الخامس',a:'scoreList.length',code:true},{q:'السؤال السادس',a:'let scoreList = [52, 90, 70, 83, 63, 72, 89];\nfor (let i = 0; i < scoreList.length; i++) {\n  if (scoreList[i] >= 80) {\n    console.log("Pass");\n  }\n}',code:true}]},
  {num:28,qs:[{q:'السؤال الأول',a:'11',code:false},{q:'السؤال الثاني',a:'10 11 12',code:false},{q:'السؤال الثالث',a:'5 6 7',code:false},{q:'السؤال الرابع',a:'let numList = [2, 4, 6, 8];\nfor (let num of numList) {\n  console.log(num);\n}',code:true},{q:'السؤال الخامس',a:'let numList = [2, 4, 6, 8];\nfor (let num of numList) {\n  console.log(num);\n}',code:true}]},
  {num:29,qs:[{q:'السؤال الأول',a:'let A = 5;\nlet B = 10;\nif (A > B) {\n  console.log("A is bigger");\n} else if (A < B) {\n  console.log("B is bigger");\n}',code:true},{q:'السؤال الثاني',a:'100',code:false},{q:'السؤال الثالث',a:'Destination is the amusement park',code:false},{q:'السؤال الرابع',a:'let weather = "sunny";\nlet shop = "OPEN";\nif (weather == "sunny") {\n  if (shop == "OPEN") {\n    console.log("Go to the shop");\n  }\n} else {\n  console.log("Staying at home");\n}',code:true},{q:'السؤال الخامس',a:'let weather = "rain";\nlet time = "morning";\nif (weather == "rain") {\n  if (time == "morning") {\n    console.log("Let\'s go to the movie theater");\n  } else if (time == "noon") {\n    console.log("Let\'s go to the library");\n  } else {\n    console.log("Let\'s stay at home");\n  }\n} else {\n  console.log("Let\'s go for a walk");\n}',code:true}]},
  {num:30,qs:[{q:'السؤال الأول',a:'5 6 7',code:false},{q:'السؤال الثاني',a:'let numList = [2, 4, 6, 8];\nfor (let num of numList) {\n  console.log(num);\n}',code:true},{q:'السؤال الثالث',a:'let wordList = ["Good morning", "Good night", "Hello"];\nfor (let word of wordList) {\n  console.log(word);\n}',code:true},{q:'السؤال الرابع',a:'100',code:false},{q:'السؤال الخامس',a:'Destination is the amusement park',code:false},{q:'السؤال السادس',a:'let weather = "rain";\nlet time = "morning";\nif (weather == "rain") {\n  if (time == "morning") {\n    console.log("Let\'s go to the movie theater");\n  } else if (time == "noon") {\n    console.log("Let\'s go to the library");\n  } else {\n    console.log("Let\'s stay at home");\n  }\n} else {\n  console.log("Let\'s go for a walk");\n}',code:true}]},
  {num:31,qs:[{q:'السؤال الأول',a:'function calculation3(a, b, c) {\n  let result = a * b * c;\n  return result;\n}\nconsole.log(calculation3(2, 3, 4));',code:true},{q:'السؤال الثاني',a:'console.log(calculation3(3, 5, 10));',code:true},{q:'السؤال الثالث',a:'function calculation3(a, b, c) {\n  let result = a * b * c;\n  return result;\n}\nlet num1 = calculation3(5, 10, 15);\nconsole.log(num1);',code:true},{q:'السؤال الرابع',a:'function calculation3(a, b, c) {\n  let result = a * b * c;\n  return result;\n}\nlet num1 = calculation3(5, 10, 15);\nconsole.log(num1);\nlet num2 = calculation3(4, 4, 4);\nconsole.log(num2);',code:true},{q:'السؤال الخامس',a:'console.log(Math.min(num1, num2, num3));',code:true}]},
  {num:32,qs:[{q:'السؤال الأول',a:'let score of scoreList',code:true},{q:'السؤال الثاني',a:'92 88 80',code:false},{q:'السؤال الثالث',a:'let heightList = [154, 138, 140, 180, 170];\nfor (let height of heightList) {\n  if (height >= 150) {\n    console.log(height);\n  }\n}',code:true},{q:'السؤال الرابع',a:'إذا كان طولك 140 سم أو أكثر، يمكنك الركوب بمفردك',code:false},{q:'السؤال الخامس',a:'let height = 148;\nlet age = 14;\nif (height >= 140) {\n  if (age >= 12) {\n    console.log("You can ride alone");\n  } else {\n    console.log("Please ride with someone who is 18 years or older");\n  }\n} else {\n  console.log("You cannot ride");\n}',code:true}]},
  {num:33,qs:[{q:'السؤال الأول',a:'console.log(calc3(3, 5, 10));',code:true},{q:'السؤال الثاني',a:'let num1 = calc3(5, 10, 15);',code:true},{q:'السؤال الثالث',a:'let num2 = calc3(4, 4, 4);\nconsole.log(num2);',code:true},{q:'السؤال الرابع',a:'console.log(Math.min(num1, num2, num3));',code:true},{q:'السؤال الخامس',a:'80 88 92',code:false},{q:'السؤال السادس',a:'إذا كان عمرك 12 سنة أو أكثر وكان طولك 140 سم أو أكثر، يمكنك الركوب',code:false}]},
  {num:34,qs:[{q:'السؤال الأول',a:'<p>Menu</p>\n<ul>\n  <li>Hamburger</li>\n  <li>Pizza</li>\n  <li>Sandwich</li>\n</ul>',code:true},{q:'السؤال الثاني',a:'<img src="cody.png">',code:true},{q:'السؤال الثالث',a:'يتم عرض النص "Tomato" باللون الأحمر',code:false},{q:'السؤال الرابع',a:'<p>Phone Number</p>\n<input type="text">\n<input type="button" value="Enter">',code:true},{q:'السؤال الخامس',a:'<input type="button" value="Submit">',code:true}]},
  {num:35,qs:[{q:'السؤال الأول',a:'<p class="cat">CAT</p>',code:true},{q:'السؤال الثاني',a:'.btn:hover {\n  background-color: red;\n}',code:true},{q:'السؤال الثالث',a:'.btn:hover {\n  background-color: red;\n  transition: 5s;\n}',code:true},{q:'السؤال الرابع',a:'double',code:false},{q:'السؤال الخامس',a:'h1 {\n  border: 10px solid blue;\n}',code:true}]},
  {num:36,qs:[{q:'السؤال الأول',a:'<p>Menu</p>\n<ul>\n  <li>Hamburger</li>\n  <li>Pizza</li>\n  <li>Sandwich</li>\n</ul>',code:true},{q:'السؤال الثاني',a:'يتم عرض النص "Tomato" باللون الأحمر',code:false},{q:'السؤال الثالث',a:'<p>Phone Number</p>\n<input type="text">\n<input type="button" value="Enter">',code:true},{q:'السؤال الرابع',a:'<input type="button" value="Submit">',code:true},{q:'السؤال الخامس',a:'.btn:hover {\n  background-color: red;\n}',code:true},{q:'السؤال السادس',a:'.btn:hover {\n  background-color: red;\n  transition: 5s;\n}',code:true},{q:'السؤال السابع',a:'double',code:false},{q:'السؤال الثامن',a:'h1 {\n  border: 10px solid blue;\n}',code:true}]},
  {num:37,qs:[{q:'السؤال الأول',a:'let color = "green";\nif (color == "red") {\n  console.log("Red");\n} else if (color == "blue") {\n  console.log("Blue");\n} else if (color == "green") {\n  console.log("Green");\n}',code:true},{q:'السؤال الثاني',a:'عندما لا تتطابق القيمة مع أيٍّ من الحالات (cases)',code:false},{q:'السؤال الثالث',a:'500~1500',code:false},{q:'السؤال الرابع',a:'let letter = "B";\nswitch (letter) {\n  case "A":\n    console.log("Well done!");\n    break;\n  case "B":\n    console.log("Keep up the good work");\n    break;\n  case "C":\n    console.log("Let\'s try a little harder");\n    break;\n}',code:true},{q:'السؤال الخامس',a:'let letter = "D";\nswitch (letter) {\n  case "A":\n    console.log("Well done!");\n    break;\n  case "B":\n    console.log("Keep up the good work");\n    break;\n  case "C":\n    console.log("Let\'s try a little harder");\n    break;\n  default:\n    console.log("The notation is incorrect");\n    break;\n}',code:true}]},
  {num:38,qs:[{q:'السؤال الأول',a:'1',code:false},{q:'السؤال الثاني',a:'year % 12 == 0',code:true},{q:'السؤال الثالث',a:'let dayCount = 14;\nif (dayCount % 7 == 0) {\n  console.log("Let\'s eat a hamburger!");\n}',code:true},{q:'السؤال الرابع',a:'let dayCount = 11;\nswitch (dayCount % 7) {\n  case 0:\n    console.log("Let\'s eat a hamburger!");\n    break;\n  case 4:\n    console.log("Let\'s eat steak!");\n    break;\n}',code:true},{q:'السؤال الخامس',a:'let number = 20;\nswitch (number % 3) {\n  case 0:\n    console.log("Group A");\n    break;\n  case 1:\n    console.log("Group B");\n    break;\n  case 2:\n    console.log("Group C");\n    break;\n}',code:true}]},
  {num:39,qs:[{q:'السؤال الأول',a:'عندما لا تتطابق القيمة مع أي من الحالات',code:false},{q:'السؤال الثاني',a:'500~1500',code:false},{q:'السؤال الثالث',a:'let letter = "B";\nswitch (letter) {\n  case "A":\n    console.log("Well done!");\n    break;\n  case "B":\n    console.log("Keep up the good work");\n    break;\n  case "C":\n    console.log("Let\'s try a little harder");\n    break;\n}',code:true},{q:'السؤال الرابع',a:'1',code:false},{q:'السؤال الخامس',a:'let dayCount = 14;\nif (dayCount % 7 == 0) {\n  console.log("Let\'s eat a hamburger!");\n}',code:true},{q:'السؤال السادس',a:'let number = 20;\nswitch (number % 3) {\n  case 0:\n    console.log("Group A");\n    break;\n  case 1:\n    console.log("Group B");\n    break;\n  case 2:\n    console.log("Group C");\n    break;\n}',code:true}]},
  {num:40,qs:[{q:'السؤال الأول',a:'const num;',code:true},{q:'السؤال الثاني',a:'let',code:true},{q:'السؤال الثالث',a:'let',code:true},{q:'السؤال الرابع',a:'a != 100',code:true},{q:'السؤال الخامس',a:'answer1 != answer2',code:true}]},
  {num:41,qs:[{q:'السؤال الأول',a:'for (let i = 0; i < 3; i++) {\n  console.log("Programming");\n}',code:true},{q:'السؤال الثاني',a:'while (condition) {\n  process;\n}',code:true},{q:'السؤال الثالث',a:'0 1 2',code:false},{q:'السؤال الرابع',a:'let money = 1000;\nconst snacks = 230;\nwhile (money > snacks) {\n  money = money - snacks;\n  console.log(money);\n}',code:true},{q:'السؤال الخامس',a:'let money = 600;\nlet month = 0;\nwhile (money < 4000) {\n  month++;\n  money += 800;\n}\nconsole.log("Save for " + month + " months");',code:true}]},
  {num:42,qs:[{q:'السؤال الأول',a:'let',code:true},{q:'السؤال الثاني',a:'let num;\nnum = 3;\nnum = 5;\nconsole.log(num);',code:true},{q:'السؤال الثالث',a:'a != 100',code:true},{q:'السؤال الرابع',a:'while (condition) {\n  process;\n}',code:true},{q:'السؤال الخامس',a:'let money = 1000;\nconst snacks = 230;\nwhile (money > snacks) {\n  money = money - snacks;\n  console.log(money);\n}',code:true},{q:'السؤال السادس',a:'let money = 600;\nlet month = 0;\nwhile (money < 4000) {\n  month++;\n  money += 800;\n}\nconsole.log("Save for " + month + " months");',code:true}]},
  {num:43,qs:[{q:'السؤال الأول',a:'span {\n  color: green;\n}',code:true},{q:'السؤال الثاني',a:'أصفر',code:false},{q:'السؤال الثالث',a:'#ffff00',code:true},{q:'السؤال الرابع',a:'opacity: 0.6;',code:true},{q:'السؤال الخامس',a:'شفاف',code:false}]},
  {num:44,qs:[{q:'السؤال الأول',a:'<img src="mountain_hut.png" alt="Mountain hut photo">',code:true},{q:'السؤال الثاني',a:'<header>\n</header>',code:true},{q:'السؤال الثالث',a:'<div class="mountains">\n  <h1>World Mountains</h1>\n  <ul>\n    <li>Mount Everest</li>\n    <li>Mount McKinley</li>\n    <li>Mount Kilimanjaro</li>\n  </ul>\n</div>',code:true},{q:'السؤال الرابع',a:'<footer>\n</footer>',code:true},{q:'السؤال الخامس',a:'footer {\n  background-color: #e0a241;\n}',code:true}]},
  {num:45,qs:[{q:'السؤال الأول',a:'أصفر',code:false},{q:'السؤال الثاني',a:'#ffff00',code:true},{q:'السؤال الثالث',a:'شفاف',code:false},{q:'السؤال الرابع',a:'<header>\n</header>',code:true},{q:'السؤال الخامس',a:'<div class="mountains">',code:true},{q:'السؤال السادس',a:'footer {\n  background-color: #e0a241;\n}',code:true},{q:'السؤال السابع',a:'<footer>\n</footer>',code:true}]},
  {num:46,qs:[{q:'السؤال الأول',a:'3',code:false},{q:'السؤال الثاني',a:'const numList = [2, 4, 6, 8];\nfor (const num of numList) {\n  console.log(num);\n}',code:true},{q:'السؤال الثالث',a:'من بين القيم من 0 إلى 6، عدد القيم التي تقبل القسمة على 2',code:false},{q:'السؤال الرابع',a:'for (let i = 1; i < 5; i++) {\n  if (i % 3 == 0) {\n    console.log(i);\n  }\n}',code:true},{q:'السؤال الخامس',a:'10',code:false}]},
  {num:47,qs:[{q:'السؤال الأول',a:'const weather = "sunny";\nswitch (weather) {\n  case "sunny":\n  case "cloudy":\n    console.log("Let\'s go shopping");\n    break;\n  case "rainy":\n    console.log("Let\'s stay home");\n    break;\n}',code:true},{q:'السؤال الثاني',a:'const weather = "sunny";\nswitch (weather) {\n  case "sunny":\n  case "cloudy":\n    console.log("Let\'s go shopping");\n    break;\n  case "rainy":\n    console.log("Let\'s stay home");\n    break;\n}',code:true},{q:'السؤال الثالث',a:'strawberry orange apple',code:false},{q:'السؤال الرابع',a:'for (let i = 1; i <= 10; i++) {\n  switch (i % 3) {\n    case 0:\n      console.log("Student " + i + " is in Group C");\n      break;\n    case 1:\n      console.log("Student " + i + " is in Group A");\n      break;\n    case 2:\n      console.log("Student " + i + " is in Group B");\n      break;\n  }\n}',code:true},{q:'السؤال الخامس',a:'No output',code:false}]},
  {num:48,qs:[{q:'السؤال الأول',a:'3',code:false},{q:'السؤال الثاني',a:'const numList = [2, 4, 6, 8];\nfor (const num of numList) {\n  console.log(num);\n}',code:true},{q:'السؤال الثالث',a:'عدد القيم من 0 إلى 6 التي تقبل القسمة على 2',code:false},{q:'السؤال الرابع',a:'10',code:false},{q:'السؤال الخامس',a:'const weather = "sunny";\nswitch (weather) {\n  case "sunny":\n  case "cloudy":\n    console.log("Let\'s go shopping");\n    break;\n  case "rainy":\n    console.log("Let\'s stay home");\n    break;\n}',code:true},{q:'السؤال السادس',a:'for (let i = 1; i <= 10; i++) {\n  switch (i % 3) {\n    case 0:\n      console.log("Student " + i + " is in Group C");\n      break;\n    case 1:\n      console.log("Student " + i + " is in Group A");\n      break;\n    case 2:\n      console.log("Student " + i + " is in Group B");\n      break;\n  }\n}',code:true},{q:'السؤال السابع',a:'No output',code:false}]},
  {num:49,qs:[{q:'السؤال الأول',a:'num < 100',code:true},{q:'السؤال الثاني',a:'3 6 9',code:false},{q:'السؤال الثالث',a:'year % 4 == 0',code:true},{q:'السؤال الرابع',a:'Count: 0 Count: 1 Count: 3 Count: 4',code:false},{q:'السؤال الخامس',a:'let a = 0;\nlet b = 0;\nwhile (a <= 10) {\n  if (a == 5) {\n    a = a + 1;\n    continue;\n  }\n  b = b + 1;\n  a = a + 1;\n}\nconsole.log("a: " + a + " times");\nconsole.log("b: " + b + " times");',code:true}]},
  {num:50,qs:[{q:'السؤال الأول',a:'55',code:false},{q:'السؤال الثاني',a:'const score of scoreList',code:true},{q:'السؤال الثالث',a:'const scoreList = [40, 55, 67, 52, 120];\nlet sum = 0;\nfor (const score of scoreList) {\n  sum = sum + score;\n}\nconsole.log(sum);',code:true},{q:'السؤال الرابع',a:'4',code:false},{q:'السؤال الخامس',a:'sum / scoreList.length',code:true}]},
  {num:51,qs:[{q:'السؤال الأول',a:'year % 4 == 0',code:true},{q:'السؤال الثاني',a:'Count: 0 Count: 1 Count: 3 Count: 4',code:false},{q:'السؤال الثالث',a:'let a = 0;\nlet b = 0;\nwhile (a <= 10) {\n  if (a == 5) {\n    a = a + 1;\n    continue;\n  }\n  b = b + 1;\n  a = a + 1;\n}\nconsole.log("a: " + a + " times");\nconsole.log("b: " + b + " times");',code:true},{q:'السؤال الرابع',a:'const score of scoreList',code:true},{q:'السؤال الخامس',a:'sum / scoreList.length',code:true}]},
  {num:52,qs:[{q:'السؤال الأول',a:'false',code:false},{q:'السؤال الثاني',a:'1',code:false},{q:'السؤال الثالث',a:'fruitList.sort();',code:true},{q:'السؤال الرابع',a:'numList.reverse();',code:true},{q:'السؤال الخامس',a:'let guestList = ["Johnson", "Smith", "Brown", "Davis", "Wilson"];\nconsole.log(guestList.includes("Wilson"));',code:true},{q:'السؤال السادس',a:'guestList.sort();',code:true}]},
  {num:53,qs:[{q:'السؤال الأول',a:'letterList.push("dog");',code:true},{q:'السؤال الثاني',a:'letterList.pop();',code:true},{q:'السؤال الثالث',a:'cat,bird',code:false},{q:'السؤال الرابع',a:'letterList.unshift("diary");',code:true},{q:'السؤال الخامس',a:'let letterList = ["p", "r", "o", "g", "r", "a", "m", "y"];\nletterList.pop();\nconsole.log(letterList);',code:true},{q:'السؤال السادس',a:'let colorList = ["red", "blue", "yellow"];\ncolorList.unshift("green");\nconsole.log(colorList);',code:true}]},
  {num:54,qs:[{q:'السؤال الأول',a:'numList.reverse();',code:true},{q:'السؤال الثاني',a:'1',code:false},{q:'السؤال الثالث',a:'orange,banana',code:false},{q:'السؤال الرابع',a:'letterList.push("apple");',code:true},{q:'السؤال الخامس',a:'let guestList = ["Johnson", "Smith", "Brown", "Davis", "Wilson"];\nconsole.log(guestList.includes("Wilson"));',code:true},{q:'السؤال السادس',a:'guestList.sort();',code:true},{q:'السؤال السابع',a:'letterList.pop();',code:true},{q:'السؤال الثامن',a:'colorList.unshift("green");',code:true}]}
];

export const chaptersPy: Chapter[] = [
  {num:1,qs:[{q:'السؤال الأول',a:'print("Hello")',code:true},{q:'السؤال الثاني',a:'print("Good morning")',code:true},{q:'السؤال الثالث',a:'print("programming")',code:true},{q:'السؤال الرابع',a:'print("hello")',code:true},{q:'السؤال الخامس',a:'#Write a comment here',code:true},{q:'السؤال السادس',a:'print("Hello")\nprint("My name is")\n#print("Rick")\nprint("Cody")',code:true}]},
  {num:2,qs:[{q:'السؤال الأول',a:'print(50 + 100)',code:true},{q:'السؤال الثاني',a:'/',code:true},{q:'السؤال الثالث',a:'print(19 + 40)',code:true},{q:'السؤال الرابع',a:'print(7 - 2)',code:true},{q:'السؤال الخامس',a:'print(15 / 5)',code:true},{q:'السؤال السادس',a:'print("Today is the 17th. 7 days ago was the " + str(17 - 7) + "th.")',code:true},{q:'السؤال السابع',a:'print("The answer is " + str(2 * 5) + ".")',code:true},{q:'السؤال الثامن',a:'نوع السلسلة النصية',code:false},{q:'السؤال التاسع',a:'print(type("1"))',code:true}]},
  {num:3,qs:[{q:'السؤال الأول',a:'score = 0',code:true},{q:'السؤال الثاني',a:'print(score)',code:true},{q:'السؤال الثالث',a:'number = 0',code:true},{q:'السؤال الرابع',a:'number = 0\nnumber = 100',code:true},{q:'السؤال الخامس',a:'number = 0\nnumber = 10\nprint(number)',code:true},{q:'السؤال السادس',a:'number = 3\nnumber = number + 10\nprint(number)',code:true}]},
  {num:4,qs:[{q:'السؤال الأول',a:'print("Hello")',code:true},{q:'السؤال الثاني',a:'print("hello")',code:true},{q:'السؤال الثالث',a:'#I\'ll leave this text here.\nprint("Comment out the first line")',code:true},{q:'السؤال الرابع',a:'print(5 + 7)',code:true},{q:'السؤال الخامس',a:'*',code:true},{q:'السؤال السادس',a:'print("The answer is " + str(3 * 4) + ".")',code:true},{q:'السؤال السابع',a:'number = 0',code:true},{q:'السؤال الثامن',a:'num = 5\nprint(num)',code:true}]},
  {num:5,qs:[{q:'السؤال الأول',a:'num = 5\nprint(num)',code:true},{q:'السؤال الثاني',a:'if conditional_expression:\n    process',code:true},{q:'السؤال الثالث',a:'num == 50',code:true},{q:'السؤال الرابع',a:'num = 100\nif num == 100:\n    print("Correct")',code:true},{q:'السؤال الخامس',a:'False',code:false}]},
  {num:6,qs:[{q:'السؤال الأول',a:'if conditional_expression:\n    A\nelse:\n    B',code:true},{q:'السؤال الثاني',a:'num = 5\nif num == 10:\n    print("Win")\nelse:\n    print("No prize")',code:true},{q:'السؤال الثالث',a:'num <= 80',code:true},{q:'السؤال الرابع',a:'num > 30',code:true},{q:'السؤال الخامس',a:'score = 80\nif score >= 60:\n    print("Pass")\nelse:\n    print("Fail")',code:true}]},
  {num:7,qs:[{q:'السؤال الأول',a:'if condition:\n    A\nelif conditions:\n    B',code:true},{q:'السؤال الثاني',a:'elif num == 2:\n    print("It\'s 2")',code:true},{q:'السؤال الثالث',a:'elif score >= 80:\n    print("Pass")',code:true},{q:'السؤال الرابع',a:'So close',code:false},{q:'السؤال الخامس',a:'egg = 5\nif egg == 0:\n    print("Out of stock")\nelif egg <= 3:\n    print("Low stock")\nelse:\n    print("In stock")',code:true}]},
  {num:8,qs:[{q:'السؤال الأول',a:'num = 7\nif num == 7:\n    print("Win")',code:true},{q:'السؤال الثاني',a:'True',code:false},{q:'السؤال الثالث',a:'score = 70\nif score >= 60:\n    print("Pass")\nelse:\n    print("Fail")',code:true},{q:'السؤال الرابع',a:'num < 20',code:true},{q:'السؤال الخامس',a:'num = 100\nif num == 100:\n    print("Win")\nelse:\n    print("No prize")',code:true},{q:'السؤال السادس',a:'Pass',code:false},{q:'السؤال السابع',a:'num = 4\nif num <= 3:\n    print("It\'s A")\nelif num >= 6:\n    print("It\'s B")\nelse:\n    print("It\'s C")',code:true}]},
  {num:9,qs:[{q:'السؤال الأول',a:'A and B',code:true},{q:'السؤال الثاني',a:'A or B',code:true},{q:'السؤال الثالث',a:'Regular price',code:false},{q:'السؤال الرابع',a:'if a == 5 or b == 10:',code:true},{q:'السؤال الخامس',a:'if a >= 2 and b >= 3:',code:true}]},
  {num:10,qs:[{q:'السؤال الأول',a:'for',code:true},{q:'السؤال الثاني',a:'i = i + 1',code:true},{q:'السؤال الثالث',a:'for i in range(10):',code:true},{q:'السؤال الرابع',a:'for i in range(5):\n    print("Hello")',code:true},{q:'السؤال الخامس',a:'for i in range(7):\n    print("Hello")',code:true}]},
  {num:11,qs:[{q:'السؤال الأول',a:'A or B',code:true},{q:'السؤال الثاني',a:'It\'s A',code:false},{q:'السؤال الثالث',a:'i = i + 1',code:true},{q:'السؤال الرابع',a:'for i in range(10):\n    process',code:true},{q:'السؤال الخامس',a:'hello\nhello',code:false},{q:'السؤال السادس',a:'for i in range(10):\n    print("Good morning")',code:true},{q:'السؤال السابع',a:'if a >= 2 and b >= 3:',code:true},{q:'السؤال الثامن',a:'for i in range(3):\n    print("Hello")',code:true}]},
  {num:12,qs:[{q:'السؤال الأول',a:'round(1.8)',code:true},{q:'السؤال الثاني',a:'print(random.random())',code:true},{q:'السؤال الثالث',a:'print(math.floor(10.5))',code:true},{q:'السؤال الرابع',a:'import math\nprint(round(5.5))\nprint(math.floor(8.8))',code:true},{q:'السؤال الخامس',a:'if random.random() >= 0.5:',code:true},{q:'السؤال السادس',a:'print(math.floor(random.random() * 10))',code:true}]},
  {num:13,qs:[{q:'السؤال الأول',a:'60',code:false},{q:'السؤال الثاني',a:'def calc(num):\n    process',code:true},{q:'السؤال الثالث',a:'15',code:false},{q:'السؤال الرابع',a:'print(calc(3))',code:true},{q:'السؤال الخامس',a:'return result',code:true}]},
  {num:14,qs:[{q:'السؤال الأول',a:'print(round(5.7))',code:true},{q:'السؤال الثاني',a:'import math\nprint(round(5.5))\nprint(math.floor(5.5))',code:true},{q:'السؤال الثالث',a:'print(max(10, 20))\nprint(min(10, 20))',code:true},{q:'السؤال الرابع',a:'import random\nprint(random.random())',code:true},{q:'السؤال الخامس',a:'def split4(total):\n    result = total / 4\n    return result\nprint(split4(1200))',code:true},{q:'السؤال السادس',a:'def calc(num):\n    process',code:true},{q:'السؤال السابع',a:'return result',code:true},{q:'السؤال الثامن',a:'print(calc(3))',code:true}]},
  {num:15,qs:[{q:'السؤال الأول',a:'num = [5, 10, 15]',code:true},{q:'السؤال الثاني',a:'15',code:false},{q:'السؤال الثالث',a:'print(num)',code:true},{q:'السؤال الرابع',a:'6',code:false},{q:'السؤال الخامس',a:'print(len(num))',code:true}]},
  {num:16,qs:[{q:'السؤال الأول',a:'import array\nrank_array = array.array("i", [3, 1, 3, 2, 1])',code:true},{q:'السؤال الثاني',a:'30',code:false},{q:'السؤال الثالث',a:'import array\nround_array = array.array("i", [1, 2, 3, 4, 5])\nprint(round_array[1])\nprint(round_array[4])',code:true},{q:'السؤال الرابع',a:'6',code:false},{q:'السؤال الخامس',a:'[38 53 65]',code:false}]},
  {num:17,qs:[{q:'السؤال الأول',a:'15',code:false},{q:'السؤال الثاني',a:'print(num)',code:true},{q:'السؤال الثالث',a:'6',code:false},{q:'السؤال الرابع',a:'30',code:false},{q:'السؤال الخامس',a:'import array\nrank_array = array.array("i", [3, 1, 3, 2, 1])',code:true},{q:'السؤال السادس',a:'6',code:false}]},
  {num:18,qs:[{q:'السؤال الأول',a:'ON',code:false},{q:'السؤال الثاني',a:'<class "bool">',code:false},{q:'السؤال الثالث',a:'str',code:false},{q:'السؤال الرابع',a:'B',code:false},{q:'السؤال الخامس',a:'ON',code:false}]},
  {num:19,qs:[{q:'السؤال الأول',a:'import math\nprint(math.floor(4.7))',code:true},{q:'السؤال الثاني',a:'5\n6',code:false},{q:'السؤال الثالث',a:'رقم من 0 إلى أقل من 1',code:false},{q:'السؤال الرابع',a:'import math\nimport random\nprint(math.floor(random.random() * 10))',code:true},{q:'السؤال الخامس',a:'import random\nif random.random() >= 0.7:\n    print("Grand prize!")\nelse:\n    print("Consolation prize")',code:true}]},
  {num:20,qs:[{q:'السؤال الأول',a:'if is_ready:',code:true},{q:'السؤال الثاني',a:'print(type(is_ready))',code:true},{q:'السؤال الثالث',a:'result = True\nresult = False',code:true},{q:'السؤال الرابع',a:'import math\nprint(math.floor(64.8 / 9.5))',code:true},{q:'السؤال الخامس',a:'import math\nimport random\nprint(math.floor(random.random() * 10))',code:true}]},
  {num:21,qs:[{q:'السؤال الأول',a:'elif A < B:\n    print("B is bigger")',code:true},{q:'السؤال الثاني',a:'and',code:false},{q:'السؤال الثالث',a:'if english == 100:\n    print("Math and English are 100 points")',code:true},{q:'السؤال الرابع',a:'for i in range(7):\n    print("Good morning")',code:true},{q:'السؤال الخامس',a:'ينتج عنه خطأ',code:false},{q:'السؤال السادس',a:'00010',code:false},{q:'السؤال السابع',a:'i += 5',code:true},{q:'السؤال الثامن',a:'print(divide3(12345))',code:true},{q:'السؤال التاسع',a:'def motion():',code:true},{q:'السؤال العاشر',a:'def mul(num1, num2):\n    result = num1 * num2\n    return result\nprint(mul(9, 7))',code:true}]},
  {num:22,qs:[{q:'السؤال الأول',a:'num = 1\nfor i in range(5):\n    num = num * 7\nprint(num)',code:true},{q:'السؤال الثاني',a:'1 → 2 → 3 → 4 → 5 → 6 → 7',code:false},{q:'السؤال الثالث',a:'num = 5040\nfor i in range(1, 6):\n    num = num / i\nprint(num)',code:true},{q:'السؤال الرابع',a:'print(mark_list[5])',code:true},{q:'السؤال الخامس',a:'print(len(mark_list))',code:true},{q:'السؤال السادس',a:'for i in range(len(mark_list)):\n    if mark_list[i] >= 85:\n        print("85 or above")',code:true}]},
  {num:23,qs:[{q:'السؤال الأول',a:'14',code:false},{q:'السؤال الثاني',a:'8\n11\n14',code:false},{q:'السؤال الثالث',a:'3\n4\n5',code:false},{q:'السؤال الرابع',a:'for point in point_list:\n    print(point)',code:true},{q:'السؤال الخامس',a:'word_list = ["Good morning", "Good night", "Hello"]\nfor word in word_list:\n    print(word)',code:true}]},
  {num:24,qs:[{q:'السؤال الأول',a:'8\n11\n14',code:false},{q:'السؤال الثاني',a:'for point in point_list:\n    print(point)',code:true},{q:'السؤال الثالث',a:'word_list = ["good morning", "good night", "hello"]\nfor word in word_list:\n    print(word)',code:true},{q:'السؤال الرابع',a:'100',code:false},{q:'السؤال الخامس',a:'الوجهة هي مدينة الملاهي',code:false},{q:'السؤال السادس',a:'if weather == "rainy":\n    if time == "morning":\n        print("Let\'s go to the movie theater")\n    elif time == "noon":\n        print("Let\'s go to the library")\n    else:\n        print("Let\'s stay home")\nelse:\n    print("Let\'s go for a walk")',code:true}]},
  {num:25,qs:[{q:'السؤال الأول',a:'def sum(stage1_time, stage2_time, stage3_time):\n    time = stage1_time + stage2_time + stage3_time\n    return time',code:true},{q:'السؤال الثاني',a:'teamA = sum(37.5, 62.5, 56.5)\nprint(teamA)',code:true},{q:'السؤال الثالث',a:'teamB = sum(55, 55, 55)\nprint(teamB)\nteamC = sum(54.5, 55, 55)\nprint(teamC)',code:true},{q:'السؤال الرابع',a:'min(teamA, teamB, teamC)',code:true},{q:'السؤال الخامس',a:'for day in record_list:',code:true},{q:'السؤال السادس',a:'if day == "Present":\n    count = count + 1',code:true},{q:'السؤال السابع',a:'if weather == "sunny":\n    print("Play in the park")\nelse:\n    print("Watch a movie")',code:true},{q:'السؤال الثامن',a:'if main_ticket == "fish and chips ticket":\n    print("Exchange it with Cody")\nelse:\n    print("Use the steak ticket")',code:true}]}
];

export const chaptersFin: Chapter[] = [
  {num:1,qs:[{q:'السؤال الأول',a:'لأن من الصعب أن تجد شخصًا يملك ما تريده ويريد أيضًا ما تملكه.',code:false},{q:'السؤال الثاني',a:'ضمان الحكومة وثقة المجتمع المشتركة بأن "يمكن استخدام هذا لشراء الأشياء".',code:false},{q:'السؤال الثالث',a:'التضخم المفرط.',code:false},{q:'السؤال الرابع',a:'وحدة الحساب.',code:false},{q:'السؤال الخامس',a:'وسيلة التبادل.',code:false},{q:'السؤال السادس',a:'القدرة الشرائية.',code:false},{q:'السؤال السابع',a:'نظام يخزّن معلومات المال كبيانات رقمية ويستخدمها عبر بطاقة أو هاتف.',code:false},{q:'السؤال الثامن',a:'لأنها لا يُصدرها بنك مركزي، فتقلبات الأسعار كبيرة جدًا.',code:false},{q:'السؤال التاسع',a:'CBDC يُصدرها البنك المركزي ولها نفس دعم الثقة الذي تتمتع به العملة القانونية.',code:false},{q:'السؤال العاشر',a:'لتوصيل الخدمات المالية حتى لمن لا يستطيعون الحصول على حساب بنكي، مما يتيح المشاركة في النشاط الاقتصادي.',code:false}]},
  {num:2,qs:[{q:'السؤال الأول',a:'نظام يوصّل المال من أصحاب الفائض إلى من يحتاجون إلى المال',code:false},{q:'السؤال الثاني',a:'التمويل غير المباشر',code:false},{q:'السؤال الثالث',a:'التمويل المباشر',code:false},{q:'السؤال الرابع',a:'بنك البنوك',code:false},{q:'السؤال الخامس',a:'شركة الأوراق المالية',code:false},{q:'السؤال السادس',a:'شركات التأمين تستثمر الأقساط التي تجمعها، مساهمة في حركة مال المجتمع',code:false},{q:'السؤال السابع',a:'الأموال ← الاستثمار ← التوظيف ← الاستهلاك ← الإيرادات الضريبية',code:false},{q:'السؤال الثامن',a:'أقرضت البنوك مبالغ كبيرة حتى لأشخاص ذوي قدرة سداد منخفضة، مما أدى إلى تخلّف واسع عن الدفع',code:false},{q:'السؤال التاسع',a:'لا يستطيع الحصول على حساب بنكي وهو في حالة لا تصله فيها فوائد الربط المالي',code:false},{q:'السؤال العاشر',a:'نظام يجمع فيه أصدقاء موثوقون المال معًا ويتناوبون على استلام مبالغ إجمالية',code:false}]},
  {num:3,qs:[{q:'السؤال الأول',a:'مع وجود كثير من الناس الذين يريدون الشراء، من المرجح أن يرتفع السعر.',code:false},{q:'السؤال الثاني',a:'في منطقة، شركة واحدة فقط تزوّد المياه ويجب على السكان استخدامها.',code:false},{q:'السؤال الثالث',a:'دواء مضاد للحمى مهم تتناوله عندما تكون مصابًا بحمى.',code:false},{q:'السؤال الرابع',a:'معدل النمو الاقتصادي +٣%، والاقتصاد ينمو.',code:false},{q:'السؤال الخامس',a:'الناتج المحلي الإجمالي يُظهر إجمالي إنتاج الدولة، ومؤشر أسعار المستهلك يُظهر تغيّرات الأسعار.',code:false},{q:'السؤال السادس',a:'بما أن أشخاصًا أكثر يُسرَّحون، يرتفع معدل البطالة في هذه الدولة.',code:false},{q:'السؤال السابع',a:'دخل من تصدير مصر النفط والغاز الطبيعي لدول أجنبية.',code:false},{q:'السؤال الثامن',a:'تُحدَّد الأسعار بالطلب والعرض، ويمكن للأفراد بدء مشاريع تجارية بحرية.',code:false},{q:'السؤال التاسع',a:'تزيد الحكومة الأعمال العامة، ويزيد البنك المركزي المعروض النقدي.',code:false},{q:'السؤال العاشر',a:'انخفاض الواردات ← انخفاض العرض المحلي ← ارتفاع مؤشر أسعار المستهلك ← يستجيب البنك المركزي بالسياسة النقدية.',code:false}]},
  {num:4,qs:[{q:'السؤال الأول',a:'إنه شكل واجب من العطاء مُعرَّف كأحد أركان الإسلام الخمسة.',code:false},{q:'السؤال الثاني',a:'هو الحد الأدنى للثروة الذي ينشأ عنده واجب دفع الزكاة.',code:false},{q:'السؤال الثالث',a:'الزكاة واجب بمبلغ ومستفيدين ثابتين، بينما الصدقة طوعية وحرة.',code:false},{q:'السؤال الرابع',a:'حمل ثروة تتجاوز النصاب + حملها باستمرار لمدة سنة.',code:false},{q:'السؤال الخامس',a:'٧٥٬٠٠٠ جنيه.',code:false},{q:'السؤال السادس',a:'شخص نفد ماله خلال السفر ويواجه صعوبة في العودة إلى بيته.',code:false},{q:'السؤال السابع',a:'الزكاة واجب ديني فردي، والضرائب تحصيل بقانون الدولة.',code:false},{q:'السؤال الثامن',a:'يتدفق المال من المستفيد إلى المجتمع بأكمله، مما يؤدي إلى تقليص التفاوت.',code:false},{q:'السؤال التاسع',a:'إقراض المال واستعادة أكثر بغض النظر عن النتيجة.',code:false},{q:'السؤال العاشر',a:'الحساب والمستفيدون مُعرَّفون كواجب، مما يساهم أيضًا في تضييق التفاوت الاجتماعي.',code:false}]},
  {num:5,qs:[{q:'السؤال الأول',a:'حافلة تديرها المدينة يستقلّها المواطنون عادةً',code:false},{q:'السؤال الثاني',a:'شركة تضامن',code:false},{q:'السؤال الثالث',a:'منظمة تعمل لصالح المجتمع وتستخدم الدخل للأنشطة دون توزيعه',code:false},{q:'السؤال الرابع',a:'المتبقي بعد طرح النفقات الضرورية من المال الذي دخل الشركة',code:false},{q:'السؤال الخامس',a:'①، ②، ③',code:false},{q:'السؤال السادس',a:'شركة كبيرة يستثمر فيها مساهمون كثيرون ويديرها أعضاء مجلس إدارة مختارون',code:false},{q:'السؤال السابع',a:'①، ②، ③، ④، ⑤',code:false},{q:'السؤال الثامن',a:'نهج تعمل فيه شركة بمسؤولية تجاه نطاق واسع من الأطراف التي تتصل بها (الناس والبيئة)',code:false},{q:'السؤال التاسع',a:'شركة أغذية تصنع منتجات مع اتباع معايير السلامة المُقرَّرة بشكل صحيح',code:false},{q:'السؤال العاشر',a:'①، ②، ③، ⑤',code:false}]},
  {num:6,qs:[{q:'السؤال الأول',a:'الأسر، والشركات، والحكومة',code:false},{q:'السؤال الثاني',a:'المبدأ القائل بأن عندما تنظر إلى حركة الاقتصاد كله من ثلاثة منظورات، الإجماليات دائمًا بنفس الحجم',code:false},{q:'السؤال الثالث',a:'ظاهرة تتسلسل فيها دورة واحدة من الصرف، ولمجتمع بأكمله تُخلَق حركة اقتصادية أكبر من المبلغ الأول',code:false},{q:'السؤال الرابع',a:'سلسلة التدفقات من توفير المواد الخام، عبر المعالجة والتوزيع، إلى الوصول ليد المستهلك',code:false},{q:'السؤال الخامس',a:'المقدار المتبقي بعد طرح تكلفة الشراء من سعر البيع',code:false},{q:'السؤال السادس',a:'آلية تتخصّص فيها الدول في ما تتميّز فيه وتستطيع إنتاجه بفعالية',code:false},{q:'السؤال السابع',a:'آلية لا تفعل فيها كل شيء داخليًا بل تترك جزءًا من العمل لشركات متخصصة خارجية',code:false},{q:'السؤال الثامن',a:'ضريبة الشركات ضريبة تدفع فيها شركة جزءًا من ربح الشركة للحكومة، وضريبة الدخل ضريبة يدفع فيها فرد عامل جزءًا من دخله للحكومة',code:false},{q:'السؤال التاسع',a:'آلية عند بدء محل يتعامل مع الطعام، لا يمكنك الفتح دون الحصول على إذن النظافة من الحكومة',code:false},{q:'السؤال العاشر',a:'آلية تُنشئ فيها الحكومة منطقة اقتصادية خاصة وتجلب شركات من الخارج بإعطاء معاملة تفضيلية على الضرائب والقواعد',code:false}]},
  {num:7,qs:[{q:'السؤال الأول',a:'دخل العمل',code:false},{q:'السؤال الثاني',a:'الأجر الاسمي هو المقدار المدفوع كراتب، والأجر الحقيقي هو الأجر المرئي بالقدرة الشرائية الفعلية مع أخذ تغيّرات الأسعار بالحسبان',code:false},{q:'السؤال الثالث',a:'مال يرسله المصريون العاملون بالخارج لأسرهم في البيت، أصبح مصدر دخل مهمًا لاقتصاد مصر',code:false},{q:'السؤال الرابع',a:'أمثلة التكلفة الثابتة هي الإيجار ورسوم الاتصالات الأساسية، وأمثلة التكلفة المتغيّرة هي تكاليف الطعام وتكاليف الضروريات اليومية',code:false},{q:'السؤال الخامس',a:'نسبة الدخل المتاح للتصرف الموضوعة نحو الاستهلاك هي الميل للاستهلاك، والنسبة الموضوعة نحو الادّخار هي الميل للادّخار',code:false},{q:'السؤال السادس',a:'إذا اخترت المساعدة في البيت، التعلّم الذي كنت ستكسبه من الدراسة يصبح تكلفة الفرصة البديلة',code:false},{q:'السؤال السابع',a:'المال الذي تستطيع الأسرة استخدامه بحرية فعليًا، بعد طرح الضرائب واشتراكات التأمين الاجتماعي من المقدار المدفوع كراتب',code:false},{q:'السؤال الثامن',a:'يحتلّ استهلاك الأسر الجزء الأكبر ضمن الناتج المحلي الإجمالي، وهو اللاعب الرئيسي الأكبر الذي يحمل الاستهلاك ضمن الاقتصاد',code:false},{q:'السؤال التاسع',a:'ظاهرة يعمل فيها الادّخار، المنطقي لأسرة فردية، على تبريد الاقتصاد عندما يحدث في نفس الوقت عبر المجتمع بأكمله',code:false},{q:'السؤال العاشر',a:'آلية تتحمّل فيها الحكومة جزءًا من سعر منتج حتى تستطيع الأسرة شراءه بأرخص. يأتي المال من الضرائب',code:false}]},
  {num:8,qs:[{q:'السؤال الأول',a:'مرفق مياه تديره الحكومة الوطنية أو المحلية',code:false},{q:'السؤال الثاني',a:'شكل يدير فيه فرد المشروع، ويعود كل من الدخل المكتسب والديون إلى الفرد بالكامل',code:false},{q:'السؤال الثالث',a:'شكل يتحمّل فيه كل المستثمرين مسؤولية فقط بحدود استثمارهم',code:false},{q:'السؤال الرابع',a:'مشهد لا تستطيع فيه شركة تضامن سداد دَين كبير بعد ذلك، ويسدّد مستثمر المبلغ كاملًا حتى باستخدام أصوله الشخصية',code:false},{q:'السؤال الخامس',a:'الشركة منظمة هدفها الأساسي السعي للربح، لكن المنظمة غير الربحية تهدف للمساهمة الاجتماعية',code:false},{q:'السؤال السادس',a:'المال المتبقي في اليد بعد طرح النفقات من الإيرادات',code:false},{q:'السؤال السابع',a:'٩٠٬٠٠٠ جنيه',code:false},{q:'السؤال الثامن',a:'تكاليف المواد الخام. هي الأكبر بين النفقات، فتقليصها له الأثر الأكبر على ربح الشركة',code:false},{q:'السؤال التاسع',a:'المساهمون الذين يستثمرون في الشركة والأشخاص الذين يديرونها فعليًا مُقسَّمون إلى مناصب منفصلة',code:false},{q:'السؤال العاشر',a:'①، ②، و③',code:false},{q:'السؤال 11',a:'CSR. ينطبق على فكرة عمل الشركة بمسؤولية تجاه نطاق واسع من الأطراف',code:false},{q:'السؤال 12',a:'البيئة، والمجتمع، والحوكمة، المحاور الثلاثة لتقييم شركة',code:false},{q:'السؤال 13',a:'مراعاة القوانين واللوائح الداخلية وحتى قواعد وأخلاقيات المجتمع أثناء العمل',code:false},{q:'السؤال 14',a:'الامتثال أساس CSR، القاعدة لتحقيق المسؤولية الاجتماعية',code:false},{q:'السؤال 15',a:'لدعم أنشطة الشركة وتنشيط الاقتصاد كله',code:false},{q:'السؤال 16',a:'تنخفض قدرة الأسر الشرائية ودخل الشركات أيضًا، وفي النهاية تنخفض الإيرادات الضريبية ويتأثر الكل',code:false},{q:'السؤال 17',a:'الصرف الأولي يُولِّد استهلاكًا جديدًا واحدًا تلو الآخر، وتتضخّم حركة مال المجتمع كله أكبر من الصرف الأولي',code:false},{q:'السؤال 18',a:'سلسلة التوريد. تدفق المنتجات من المواد الخام إلى المستهلك',code:false},{q:'السؤال 19',a:'٢٬٠٠٠ جنيه',code:false},{q:'السؤال 20',a:'منظور يركّز على كم قيمة تتولّد في كل مرحلة من المواد الخام إلى المستهلك',code:false},{q:'السؤال 21',a:'آلية تتولّى فيها كل دولة إنتاج مجالها التخصصي وتتكامل من خلال التجارة',code:false},{q:'السؤال 22',a:'آلية لتفويض جزء من عمليات الشركة الخاصة لشركة متخصصة خارجية',code:false},{q:'السؤال 23',a:'ضريبة تدفعها شركة للحكومة وفقًا لربح الشركة لتلك السنة',code:false},{q:'السؤال 24',a:'تُفرَض ضريبة الدخل على دخل فرد، وضريبة الشركات على ربح شركة',code:false},{q:'السؤال 25',a:'خدمات كالطرق والمياه والتعليم والشرطة التي تدعم بنية أساسية يستخدمها المجتمع كله',code:false},{q:'السؤال 26',a:'منطقة تضع فيها الحكومة حوافز ضريبية وما شابه في منطقة محدَّدة لجلب الاستثمار والأعمال',code:false},{q:'السؤال 27',a:'شركة أجنبية تبني مصنعًا أو فرعًا في دولة أخرى للقيام بأعمال طويلة الأمد',code:false},{q:'السؤال 28',a:'آلية تضع فيها الحكومة قواعد معينة على النشاط التجاري لحفظ سلامة السوق ونزاهته',code:false},{q:'السؤال 29',a:'كسب الثقة الاجتماعية، تصبح الشركة أكثر احتمالًا لأن يختارها العملاء والمستثمرون على المدى الطويل',code:false},{q:'السؤال 30',a:'تدفع الشركات ضرائب للحكومة، وتقدّم الحكومة خدمات عامة ومناطق اقتصادية خاصة للشركات',code:false},{q:'السؤال 31',a:'دخل العمل',code:false},{q:'السؤال 32',a:'دخل الأعمال. المتبقي بعد طرح كل النفقات الضرورية كالمشتريات والإيجار وتكاليف العمالة من الإيرادات',code:false},{q:'السؤال 33',a:'فائدة المدخرات، وتوزيعات أرباح الأسهم، ودخل تأجير العقارات، توليفة دخل مُتولِّد من الأصول',code:false},{q:'السؤال 34',a:'الأجور الاسمية هي مقدار الراتب نفسه، والأجور الحقيقية هي الأجر المرئي بمقدار ما تستطيع شراءه',code:false},{q:'السؤال 35',a:'ارتفعت الأجور الاسمية، لكن ارتفاع الأسعار كان أكبر، فلم تزد الكمية القابلة للشراء كثيرًا',code:false},{q:'السؤال 36',a:'مال يرسله شخص عامل بالخارج لأسرة تعيش في البيت',code:false},{q:'السؤال 37',a:'إجمالي المطروح: ٢٬٠٠٠ جنيه / المتبقي: ٨٬٠٠٠ جنيه',code:false},{q:'السؤال 38',a:'تُعتبَر الأجور الحقيقية قد انخفضت بمقدار ارتفاع الأسعار',code:false},{q:'السؤال 39',a:'التكاليف الثابتة: الإيجار، ورسوم الاتصالات، وأقساط التأمين / التكاليف المتغيّرة: الطعام، والترفيه، والنقل',code:false},{q:'السؤال 40',a:'١٬٠٠٠ جنيه',code:false},{q:'السؤال 41',a:'حوالي ٤٣%',code:false},{q:'السؤال 42',a:'حوالي ٧٥%',code:false},{q:'السؤال 43',a:'تنازلت عن دخل ١٥٠ جنيهًا الذي كنت ستكسبه لو اخترت العمل',code:false},{q:'السؤال 44',a:'بمجرد المراجعة، تستمر النفقات الشهرية في الانخفاض، فأثر الادّخار يدوم طويلًا',code:false},{q:'السؤال 45',a:'يحتلّ الاستهلاك الشخصي أكبر نسبة ضمن الناتج المحلي الإجمالي، داعمًا الاقتصاد كله',code:false},{q:'السؤال 46',a:'① ينخفض / ② ينخفض / ③ تقلّص',code:false},{q:'السؤال 47',a:'تنخفض العملة الأجنبية الداخلة للدولة، ويترقّق عمود رئيسي واحد لدخل العملة الأجنبية',code:false},{q:'السؤال 48',a:'تقديم دعم يساعد الأسر والشركات، مخفّفًا التراجع في الاستهلاك والاستثمار',code:false},{q:'السؤال 49',a:'بجانب الاستثمار الرأسمالي الجديد للمستقبل، وضعه أيضًا نحو عوائد للمساهمين والموظفين والمجتمع المحلي',code:false},{q:'السؤال 50',a:'عند نقص المال المتاح للتسوّق الشخصي، تحويل إيرادات الشركة للدفع',code:false}]}
];

// تقسيم المستويات الأكاديمية:
// أولى بكالوريا: 42 مستوى في البرمجة (جافا)
export const chaptersBac1Js = chaptersJs.filter((ch) => ch.num <= 42);

// تانية بكالوريا: نفس الـ 42 بتوع أولى ولكن مضاف عليهم حتى 54 مستوى
export const chaptersBac2Js = chaptersJs;

// فيديوهات حية من الأداة أثناء حل الامتحان ومحاكاة الطالب
export const toolVideos = [
  {
    src: '/media/videos/VID-20261031-WA0034.mp4',
    title: 'فيديو حل الامتحان الآلي المباشر (تخطي المنصة في 4 دقائق)',
    description: 'تسجيل شاشة حقيقي للأداة وهي بتسجل دخول بالبيانات وتكتب بالراحة وتجاوز الأسئلة بنعومة من غير ما المنصة تشك في أي حركة!',
    tag: 'البرمجة والامتحانات',
  },
  {
    src: '/media/videos/VID-20261021-WA0025(1).mp4',
    title: 'فيديو حل مواد الثقافة المالية والأسئلة المقالية والأكواد',
    description: 'شاهد استخراج الإجابات النموذجية لأسئلة المفاهيم والرسوم التفاعلية خطوة بخطوة بأعلى كفاءة ودقة.',
    tag: 'الثقافة المالية والمفاهيم',
  },
];

// لقطات الشاشة الحية المرفقة للأداة - جميعها محلولة 100% بدرجات نهائية
export const toolScreenshots = [
  {
    src: '/media/screenshots/Screenshot_20261031-100300.jpg',
    title: 'تقفيل كل المستويات PERFECT بدرجة 100%',
    description: 'جميع مستويات البرمجة محلولة بعلامة كاملة PERFECT في دقائق معدودة',
    category: 'code' as const,
  },
  {
    src: '/media/screenshots/Screenshot_20261021-155441.jpg',
    title: 'إنجاز المنهج الدراسي 100% ورادار المهارات 5/5',
    description: 'تحقيق أعلى تقييم 5/5 في المعرفة الأساسية والمفهومية والتطبيقية',
    category: 'exam' as const,
  },
  {
    src: '/media/screenshots/Screenshot_20261020-091134.jpg',
    title: 'لوحة إنجاز الثقافة المالية مقفلة بالكامل 100%',
    description: 'إنهاء فصول التمويل والاستثمار وريادة الأعمال بنسبة إنجاز 100% كاملة',
    category: 'platform' as const,
  },

  {
    src: '/media/screenshots/Screenshot_20261031-101218.jpg',
    title: 'إتقان مستويات البرمجة التفاعلية كاملة',
    description: 'حل دقيق ومحاكاة كتابة سلسة تحاكي الطالب البشري بنسبة نجاح 100%',
    category: 'code' as const,
  },
  {
    src: '/media/screenshots/Screenshot_20261031-193326.jpg',
    title: 'إنهاء اختبارات منتصف الطريق والمراجعات',
    description: 'تجاوز شامل لاختبارات الفاينال والتكليفات البرمجية الصعبة في 4 دقائق',
    category: 'code' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261018-222345_ce7fc032.jpg',
    title: 'تقرير رادار المهارات المالية 100%',
    description: 'تقفيل بنك المهارات والمعرفة الأساسية والمفهومية',
    category: 'platform' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261015-090752_b03535a7.jpg',
    title: 'درجات نهائية في الثقافة المالية',
    description: 'إنجاز التمويل والاستثمار والدرجة النهائية 5.0 من 5',
    category: 'platform' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261015-101545_19ab57ae.jpg',
    title: 'تخطي فصول الاقتصاد والمال بنجاح',
    description: 'إتمام كامل المنهج الدراسي واختبارات الفاينال',
    category: 'platform' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261014-232952_4bdbcd91.jpg',
    title: 'تقفيل رادار المهارات الكمية',
    description: 'اجتياز الاختبارات التقنية والمالية بدون أي خطأ',
    category: 'exam' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261019-124452_401c4ea6.jpg',
    title: 'إنجاز اختبارات البرمجة والجافا',
    description: 'حلول دقيقة ومثالية لكافة الفصول والأسئلة',
    category: 'code' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261019-124528_9690ca84.jpg',
    title: 'رادار المهارات المكتمل 5/5',
    description: 'تقفيل التفكير النقدي والمعرفة الأساسية بامتياز',
    category: 'exam' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261102-140132_50ee7c26.jpg',
    title: 'تجاوز اختبارات الفاينال بالهاتف',
    description: 'أداة الحل الفوري تعمل بكفاءة عالية على الهواتف',
    category: 'code' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261016-234215_b3c23869.jpg',
    title: 'نتائج الاختبارات النهائية المعتمدة',
    description: 'الحصول على الدرجات النهائية وثقة المنصة الكاملة',
    category: 'exam' as const,
  },
  {
    src: '/assets/aistudio/Screenshot_20261019-115512_39db580b.jpg',
    title: 'إتقان المنهج والمفاهيم البرمجية',
    description: 'تقفيل شامل للمستويات والمراجعات في دقائق',
    category: 'code' as const,
  },
];

export const toolScreenshotsRow1 = toolScreenshots.slice(0, 7);
export const toolScreenshotsRow2 = toolScreenshots.slice(7, 14);

// تقييمات وتعليقات الطلاب المعتمدة للأداة (أسماء وتعليقات بشرية عفوية وسريعة)
export const initialStudentReviews = [
  {
    id: 'rev-1',
    author: 'محمد سعد',
    grade: 'تانية بكالوريا',
    rating: 5,
    text: 'الأداة عظيمة خلصتلي 54 مستوى جافا في أربع دقايق بالضبط والتقرير طالع 100% تسلم إيدك يا عمر',
    time: 'منذ ساعتين',
  },
  {
    id: 'rev-2',
    author: 'أحمد وائل',
    grade: 'أولى بكالوريا',
    rating: 5,
    text: 'كلمت عمر صبري ع الواتساب ضبطلي الحساب وفي ثانية الأداة كانت حلت كل مستويات البرمجة بامتياز',
    time: 'منذ 4 ساعات',
  },
  {
    id: 'rev-3',
    author: 'محمد أحمد',
    grade: 'تانية بكالوريا - بايثون',
    rating: 5,
    text: 'مفيش أي سحل ولا وجع دماغ بتكتب بنعومة وكأن بشر قاعد يحل ورادار المهارات طالع مقفل 5/5',
    time: 'منذ 6 ساعات',
  },
  {
    id: 'rev-4',
    author: 'قصي',
    grade: 'تانية بكالوريا - المالية',
    rating: 5,
    text: 'أسرع وأدق أداة جربتها في حياتي خلصت مواد الثقافة المالية والأسئلة المقالية في دقائق معدودة',
    time: 'أمس',
  },
  {
    id: 'rev-5',
    author: 'الفيرو',
    grade: 'أولى بكالوريا',
    rating: 5,
    text: 'منقذ الدفعة بحق وحقيق وفرت عليا أسبوع سحل في الحلول والكتابة تسلم يا معلم',
    time: 'منذ يومين',
  },
  {
    id: 'rev-6',
    author: 'الكارف',
    grade: 'تانية بكالوريا',
    rating: 5,
    text: 'راجل محترم وخدوم جدا والأداة شغالة حلاوة ع الهاتف وبأعلى دقة بدون أي غلطة',
    time: 'منذ 3 أيام',
  },
];

// نصائح وإرشادات واقعية للطالب المتميز من عمر صبري
export const studentQuotes = [
  { quote: "المذاكرة الذكية مش معناه تجهد نفسك ليل نهار المتابعة أول بأول مع الاستعانة بأدوات مظبوطة بتختصر عليك طريق طويل", author: "عمر صبري" },
  { quote: "إتقان الأساسيات في البرمجة والمالية هو اللي بيفرق بين طالب تايه وطالب ماشي بثقة وفاهم هو بيعمل إيه", author: "عمر صبري" },
  { quote: "تنظيم الوقت وهدوء الأعصاب أسرع طريق لتجاوز أصعب الاختبارات والوصول للدرجات النهائية بامتياز", author: "عمر صبري" },
  { quote: "استغل وقتك صح وخلي كل دقيقة تحسب لك الحلول النموذجية بتبني عندك فهم متين وبترسخ المعلومات", author: "عمر صبري" },
  { quote: "طريق التفوق بيحتاج تفكير عملي وتركيز على هدفك اشتغل بذكاء وهتوصل لكل اللي بتتمناه بسهولة", author: "عمر صبري" },
];

export const examSolverFaqs = [
  {
    q: "ليه المنصة تحلف إنه أنت ومش هيكتشفوك؟",
    a: "عشان الأداة مش مجرد سكربت أعمى بيرمي حلول سريعة تكشفك؛ الأداة بتاخد بياناتك وتسجل دخول كأنك أنت بالظبط، وبتكتب بالراحة وتضغط في الأماكن الصح وتتنقل بين الصفحات بنعومة بشرية تامة، وفي الآخر المنصة تطلع تقرير إنك الطالب المجتهد اللي مفيش زيه!"
  },
  {
    q: "طب الليلة دي بتاخد وقت قد إيه بجد؟",
    a: "أقل من 4 دقايق بس! في الوقت اللي زميلك لسه بيكتب اسمه وبيتهته في أول سؤال، هتكون أنت مخلص كل الفصول والأسئلة ومروّق دماغك."
  },
  {
    q: "إزاي أشترك وأريح جمجمتي بدون لف ولا دوران؟",
    a: "مفيش أسهل من كده: اضغط على زرار 'كلمني' على الواتساب، والرسالة هتتجهز لوحدها: 'عاوز اشترك يخويااااا'، وأنا هظبطك في ثانية، أو كلمني دغري ع التليجرام @OmarSaabry."
  }
];

